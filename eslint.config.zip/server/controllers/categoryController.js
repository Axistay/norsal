import Category from '../models/category.js';
import cloudinary from 'cloudinary';

import dotenv from 'dotenv';
dotenv.config();

// Configure cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

// Create new category with image
export const createCategory = async (req, res) => {
  try {
    const { name, description, color, city, image } = req.body;
    
    let imageData = {
      url: '',
      public_id: ''
    };
    
    // Upload image to Cloudinary if provided
    if (image && image.startsWith('data:')) {
      try {
        const result = await cloudinary.uploader.upload(image, {
          folder: 'categories'
        });
        imageData = {
          url: result.secure_url,
          public_id: result.public_id
        };
      } catch (cloudinaryError) {
        return res.status(400).json({ message: 'Failed to upload image to Cloudinary', error: cloudinaryError.message });
      }
    }

    const newCategory = new Category({
      name,
      description,
      color,
      city,
      image: imageData
    });

    const savedCategory = await newCategory.save();
    res.status(201).json(savedCategory);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Update category with image handling
export const updateCategory = async (req, res) => {
  try {
    const { image } = req.body;
    const category = await Category.findById(req.params.id);
    
    if (!category) return res.status(404).json({ message: 'Category not found' });
    
    // Handle image update if new image provided
    if (image && image !== category.image?.url) {
      // Delete old image from Cloudinary if it exists
      if (category.image?.public_id) {
        try {
          await cloudinary.uploader.destroy(category.image.public_id);
        } catch (error) {
          console.error('Error deleting image from Cloudinary:', error);
        }
      }
      
      // Upload new image to Cloudinary
      let imageData = {
        url: '',
        public_id: ''
      };
      
      if (image.startsWith('data:')) {
        try {
          const result = await cloudinary.uploader.upload(image, {
            folder: 'categories'
          });
          imageData = {
            url: result.secure_url,
            public_id: result.public_id
          };
        } catch (cloudinaryError) {
          return res.status(400).json({ message: 'Failed to upload image to Cloudinary', error: cloudinaryError.message });
        }
      } else {
        imageData.url = image;
      }
      
      // Update with new image data
      req.body.image = imageData;
    }

    // Update category
    const updatedCategory = await Category.findOneAndUpdate(
      { _id: req.params.id }, 
      req.body, 
      {
        new: true,
        runValidators: true
      }
    );

    res.status(200).json(updatedCategory);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Delete category with image cleanup
export const deleteCategory = async (req, res) => {
  try {
    const category = await Category.findById(req.params.id);
    if (!category) return res.status(404).json({ message: 'Category not found' });

    // Delete image from Cloudinary if it exists
    if (category.image && category.image.public_id) {
      try {
        await cloudinary.uploader.destroy(category.image.public_id);
      } catch (error) {
        console.error('Error deleting image from Cloudinary:', error);
      }
    }

    await category.deleteOne();
    res.json({ message: 'Category deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all categories
export const getCategories = async (req, res) => {
  try {
    const categories = await Category.find();
    res.json(categories);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get categories by city
export const getCategoriesByCity = async (req, res) => {
  try {
    const categories = await Category.find({ city: req.params.cityId });
    res.json(categories);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ... existing code ...
export const getCategoriesCountByCity = async (req, res) => {
  try {
    const count = await Category.countDocuments({ city: req.params.cityId });
    res.json({ count });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
// ... existing code ...

// Get single category
export const getCategory = async (req, res) => {
  try {
    const category = await Category.findById(req.params.id);
    if (!category) return res.status(404).json({ message: 'Category not found' });
    res.json(category);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Upload image to a category (replaces existing image)
export const uploadImage = async (req, res) => {
  try {
    const { categoryId } = req.params;

    // Validate if file exists
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "No file uploaded"
      });
    }

    // Find the category first
    const category = await Category.findById(categoryId);
    if (!category) {
      return res.status(404).json({
        success: false,
        message: "Category not found"
      });
    }
    
    // Delete old image from Cloudinary if it exists
    if (category.image && category.image.public_id) {
      try {
        await cloudinary.uploader.destroy(category.image.public_id);
      } catch (error) {
        console.error('Error deleting existing image from Cloudinary:', error);
      }
    }

    // Upload new image to Cloudinary
    const result = await cloudinary.uploader.upload(req.file.path, { 
      folder: "categories" 
    });

    // Update category with new image
    const updatedCategory = await Category.findByIdAndUpdate(
      categoryId,
      { 
        image: {
          url: result.secure_url,
          public_id: result.public_id
        }
      },
      { new: true }
    );

    res.status(200).json({
      success: true,
      category: updatedCategory
    });
  } catch (err) {
    console.error('Upload error:', err);
    res.status(500).json({ 
      success: false, 
      message: err.message 
    });
  }
};