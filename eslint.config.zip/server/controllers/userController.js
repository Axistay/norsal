import User from '../models/user.js';
import bcrypt from 'bcryptjs';

// @desc    Add new user (Admin only)
// @route   POST /api/users
// @access  Private/Admin
export const addUser = async (req, res) => {
  try {
    const { email, password, role } = req.body;
    // Check if user exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User already exists with this email'
      });
    }

    // Create new user
    const newUser = await User.create({
      email,
      password,
      role
    });

    // Remove password from response
    newUser.password = undefined;

    res.status(201).json({
      success: true,
      data: newUser
    });

  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};

export const getAllUsers = async (req, res) => {
  try {
    const users = await User.find();
    res.status(200).json({
      success: true,
      data: users 
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};

export const deleteUser = async (req, res) => {
  try {
    const userId = req.params.id;

    const deletedUser = await User.findByIdAndDelete(userId);

    if (!deletedUser) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    } else {
      res.status(200).json({
        success: true,
        message: 'User deleted successfully'
      });
    }
  } catch (error) { 
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};



// @desc    Update user
// @route   PATCH /api/users/:id
// @access  Private/Admin
export const updateUser = async (req, res) => {
  try {
    const updates = { ...req.body };
    const userId = req.params.id;

    

    const updatedUser = await User.findByIdAndUpdate(
      userId,
      updates,
      { new: true }
    );

    if (!updatedUser) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.status(200).json({
      success: true,
      data: updatedUser
    });

  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Reset password
// @route   POST /api/users/resetPassword
// @access  Public
export const resetPassword = async (req, res) => {
  try {
    const { email, newPassword } = req.body;

    // 1) Find user by email
    const user = await User.findOne({ email }).select('+password');
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'No user found with that email'
      });
    }

    // 2) Update password
    user.password = newPassword;
    await user.save();

    // 3) Remove password from response
    user.password = undefined;

    res.status(200).json({
      success: true,
      message: 'Password updated successfully',
      data: user
    });

  } catch (error) {

    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};