import Type from '../models/type.js';
import Category from '../models/category.js';

// Create new type
export const createType = async (req, res) => {
  try {
    const { name, categoryId } = req.body;

    
    // Verify category exists
    const category = await Category.findById(categoryId);
    if (!category) return res.status(404).json({ message: 'Category not found' });
    
    const newType = new Type({ name, categoryId });
    const savedType = await newType.save();
    res.status(201).json(savedType);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Get all types
export const getTypes = async (req, res) => {
  
  try {
    const types = await Type.find().populate('categoryId');
    res.json(types);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get types by category
export const getTypesByCategory = async (req, res) => {
  try {
    const types = await Type.find({ categoryId: req.params.categoryId });
    res.json(types);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// Get single type
export const getType = async (req, res) => {
  try {
    const type = await Type.findById(req.params.id).populate('categoryId');
    if (!type) return res.status(404).json({ message: 'Type not found' });
    res.json(type);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Update type
export const updateType = async (req, res) => {
  try {
    const updatedType = await Type.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    ).populate('categoryId');
    if (!updatedType) return res.status(404).json({ message: 'Type not found' });
    res.json(updatedType);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Delete type
export const deleteType = async (req, res) => {
  try {
    const deletedType = await Type.findByIdAndDelete(req.params.id);
    if (!deletedType) return res.status(404).json({ message: 'Type not found' });
    res.json({ message: 'Type deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};