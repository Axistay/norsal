import Plate from '../models/plate.js';
import Type from '../models/type.js';
import cloudinary from 'cloudinary';
import dotenv from 'dotenv';

dotenv.config();

// Configure cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

// Create new plate with image upload
export const createPlate = async (req, res) => {
  try {
    const { title, description, price, typeId, nutrition, city } = req.body;

    // Verify type exists
    const type = await Type.findById(typeId);
    if (!type) return res.status(404).json({ message: 'Type not found' });

    let imageData = {
      url: '',
      public_id: ''
    };

    // // Upload image to Cloudinary if provided
    // if (image && image?.startsWith('data:')) {
    //   try {
    //     const result = await cloudinary.uploader.upload(image, {
    //       folder: 'plates'
    //     });
    //     imageData = {
    //       url: result.secure_url,
    //       public_id: result.public_id
    //     };
    //   } catch (cloudinaryError) {
    //     return res.status(400).json({ message: 'Failed to upload image to Cloudinary', error: cloudinaryError.message });
    //   }
    // }

    const newPlate = new Plate({
      title,
      description,
      price,
      typeId,
      nutrition,
      image: imageData,
      city
    });

    const savedPlate = await newPlate.save();
    res.status(201).json(savedPlate);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Update plate with optional image update
export const updatePlate = async (req, res) => {
  try {
    // Remove image handling logic
    // if (image && image !== plate.image?.url) {
    //   // Delete old image from Cloudinary if it exists
    //   if (plate.image?.public_id) {
    //     try {
    //       await cloudinary.uploader.destroy(plate.image.public_id);
    //     } catch (error) {
    //       console.error('Error deleting image from Cloudinary:', error);
    //     }
    //   }

    //   // Upload new image to Cloudinary
    //   let imageData = {
    //     url: '',
    //     public_id: ''
    //   };

    //   if (image.startsWith('data:')) {
    //     try {
    //       const result = await cloudinary.uploader.upload(image, {
    //         folder: 'plates'
    //       });
    //       imageData = {
    //         url: result.secure_url,
    //         public_id: result.public_id
    //       };
    //     } catch (cloudinaryError) {
    //       return res.status(400).json({ message: 'Failed to upload image to Cloudinary', error: cloudinaryError.message });
    //     }
    //   } else {
    //     imageData.url = image;
    //   }

    //   // Update with new image data
    //   req.body.image = imageData;
    // }

    // Update plate
    const updatedPlate = await Plate.findOneAndUpdate(
      { _id: req.params.id },
      req.body,
      {
        new: true,
        runValidators: true
      }
    );

    res.status(200).json(updatedPlate);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Delete plate with image cleanup
export const deletePlate = async (req, res) => {
  try {
    const plate = await Plate.findById(req.params.id);
    if (!plate) return res.status(404).json({ message: 'Plate not found' });

    // Delete image from Cloudinary if it exists
    if (plate.image && plate.image.public_id) {
      try {
        await cloudinary.uploader.destroy(plate.image.public_id);
      } catch (error) {
        console.error('Error deleting image from Cloudinary:', error);
      }
    }

    await plate.deleteOne();
    res.json({ message: 'Plate deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all plates
export const getPlates = async (req, res) => {
  try {
    const { cityId } = req.params;
    const plates = await Plate.find({ city: cityId }).populate({
      path: 'typeId',
      populate: {
        path: 'categoryId',
        model: 'Category'
      }
    });
    res.json(plates);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
// Get plates by type
export const getPlatesByType = async (req, res) => {
  try {
    const plates = await Plate.find({ typeId: req.params.typeId })
      .populate({
        path: 'typeId',
        populate: {
          path: 'categoryId',
          model: 'Category'
        }
      });
    res.json(plates);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// Get single plate
export const getPlate = async (req, res) => {
  try {
    const plate = await Plate.findById(req.params.id)
      .populate({
        path: 'typeId',
        populate: {
          path: 'categoryId',
          model: 'Category'
        }
      });
    if (!plate) return res.status(404).json({ message: 'Plate not found' });
    res.json(plate);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Upload image to a plate (replaces existing image)
export const uploadImagePlate = async (req, res) => {
  try {
    const { plateId } = req.params;

    // Validate if file exists
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "No file uploaded"
      });
    }

    // Find the plate first
    const plate = await Plate.findById(plateId);
    if (!plate) {
      return res.status(404).json({
        success: false,
        message: "Plate not found"
      });
    }

    // Delete old image from Cloudinary if it exists
    if (plate.image && plate.image.public_id) {
      try {
        await cloudinary.uploader.destroy(plate.image.public_id);
      } catch (error) {
        console.error('Error deleting existing image from Cloudinary:', error);
      }
    }

    // Upload new image to Cloudinary
    const result = await cloudinary.uploader.upload(req.file.path, {
      folder: "plates"
    });

    // Update plate with new image
    const updatedPlate = await Plate.findByIdAndUpdate(
      plateId,
      {
        image: {
          url: result.secure_url,
          public_id: result.public_id
        }
      },
      { new: true }
    );

    res.status(200).json({
      success: true,
      plate: updatedPlate
    });
  } catch (err) {
    console.error('Upload error:', err);
    res.status(500).json({
      success: false,
      message: err.message
    });
  }
};