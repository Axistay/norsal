import jwt from 'jsonwebtoken';
import User from '../models/user.js';
import { promisify } from 'util';

// Generate JWT Token
const signToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN,
  });
};



// @desc    Login user
// @route   POST /api/users/login
// @access  Public
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // 1) Check if email and password exist
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email and password',
      });
    }

    // 2) Find user by email (including password)
    const user = await User.findOne({ email }).select('+password');

    // 3) Check if user exists and password is correct
    if (!user || !(await user.comparePassword(password, user.password))) {
      return res.status(401).json({
        success: false,
        message: 'Incorrect email or password',
      });
    }

    // 4) Generate JWT token
    const token = signToken(user._id);

    // 5) Remove password from output
    user.password = undefined;

    res.status(200).json({
      success: true,
      token,
      data: {
        user,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const verifyToken = async (req, res) => {
    try {
      const token = req.headers.authorization?.split(' ')[1];
      
      if (!token) {
        return res.status(401).json({
          success: false,
          message: 'You are not logged in! Please log in to get access.',
        });
      }
  
      const decoded = await promisify(jwt.verify)(token, process.env.JWT_SECRET);
      
      res.status(200).json({
        success: true,
        data: decoded,
      });
    } catch (error) {
      if (error.name === 'TokenExpiredError') {
        return res.status(401).json({
          success: false,
          message: 'Your token has expired! Please log in again.',
          expiredAt: error.expiredAt
        });
      }
      
      if (error.name === 'JsonWebTokenError') {
        return res.status(401).json({
          success: false,
          message: 'Invalid token! Please log in again.'
        });
      }
      
      // For any other errors
      res.status(500).json({
        success: false,
        message: 'An error occurred while verifying the token'
      });
    }
  };
// @desc    Protect routes (Middleware)
// @route   - (Use before protected routes)
export const protect = async (req, res, next) => {
  try {
    // 1) Get token from headers
    let token;
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith('Bearer')
    ) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'You are not logged in! Please log in to get access.',
      });
    }

    // 2) Verify token
    const decoded = await promisify(jwt.verify)(token, process.env.JWT_SECRET);


    // 3) Check if user still exists
    const currentUser = await User.findById(decoded.id);
    if (!currentUser) {
      return res.status(401).json({
        success: false,
        message: 'The user belonging to this token no longer exists.',
      });
    }

    // 4) Grant access
    req.user = currentUser;
    next();
  } catch (error) {
    // Improved error handling
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        success: false,
        message: 'Invalid token! Please log in again.',
      });
    }
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Your token has expired! Please log in again.',
        expiredAt: error.expiredAt,
      });
    }
    return res.status(500).json({
      success: false,
      message: 'An error occurred while verifying the token',
    });
  }
};

