import mongoose from 'mongoose';


const typeSchema = new mongoose.Schema({
  name: {
    en: { type: String, required: true },
    fr: { type: String, required: true },
    es: { type: String, required: true },
    ar: { type: String, required: true }
  },
  categoryId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Category', 
    required: true 
  }
}, { timestamps: true });

export default mongoose.model('Type', typeSchema);