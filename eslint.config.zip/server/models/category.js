import mongoose from 'mongoose';

const categorySchema = new mongoose.Schema({
  name: {
    en: { type: String, required: true },
    fr: { type: String, required: true },
    es: { type: String, required: true },
    ar: { type: String, required: true }
  },
  description: {
    en: { type: String, required: true },
    fr: { type: String, required: true },
    es: { type: String, required: true },
    ar: { type: String, required: true }
  },
  color: { type: String, required: true },
  image: {
    url: { type: String, default: '' },
    public_id: { type: String, default: '' }
  },
  city: {
    type: String,
    required: true,
    index: true
  }
}, { timestamps: true });

export default mongoose.model('Category', categorySchema);