import mongoose from 'mongoose';

const nutritionSchema = new mongoose.Schema({
  calories: { type: Number, required: true },
  protein: { type: Number, required: true },
  fat: { type: Number, required: true },
  carbs: { type: Number, required: true }
});

const plateSchema = new mongoose.Schema({
  title: {
    en: { type: String, required: true },
    fr: { type: String, required: true },
    es: { type: String, required: true },
    ar: { type: String, required: true }
  },
  description: {
    en: { type: String, required: true },
    fr: { type: String, required: true },
    es: { type: String, required: true },
    ar: { type: String, required: true }
  },
  price: { type: Number, required: true },
  image: {
    url: { type: String, default: '' },
    public_id: { type: String, default: ''}
  },
  city: {
    type: String,
    required: true,
    index: true
  },
  typeId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Type',
    required: true
  },
  nutrition: { type: nutritionSchema, required: true }
}, { timestamps: true });

export default mongoose.model('Plate', plateSchema);