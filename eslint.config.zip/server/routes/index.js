import express from 'express';

import {
  createCategory,
  getCategories,
  getCategoriesByCity,
  getCategory,
  updateCategory,
  deleteCategory,
  uploadImage,
  getCategoriesCountByCity
} from '../controllers/categoryController.js';

import {
  createType,
  getTypes,
  getTypesByCategory,
  getType,
  updateType,
  deleteType
} from '../controllers/typeController.js';

import {
  createPlate,
  getPlates,
  getPlatesByType,
  getPlate,
  updatePlate,
  deletePlate,
  uploadImagePlate
} from '../controllers/plateController.js';

import {
  addUser,
  updateUser,
  resetPassword,
  deleteUser,
  getAllUsers
} from '../controllers/userController.js';

import multer from 'multer';
import { login, protect, verifyToken } from '../controllers/authController.js';
const upload = multer({ dest: 'uploads/' });

const router = express.Router();


// Auth routes
router.post('/users/login', login);
router.get('/users/verifyToken', verifyToken);

// Admin routes
router.get('/users', protect, getAllUsers);
router.post('/users', protect, addUser);          // Add new user
router.put('/users/:id', protect, updateUser);  // Update user
router.delete('/users/:id', protect, deleteUser); // Delete user

// Password reset route
router.post('/users/resetPassword', protect, resetPassword);



// Category routes with image upload
router.post('/categories', protect, upload.single('image'), createCategory);
router.put('/categories/:categoryId/image', protect, upload.single('image'), uploadImage);

router.get('/categories', getCategories);
router.get('/categories/city/:cityId', getCategoriesByCity);
router.get('/categories/count/:cityId', getCategoriesCountByCity);
router.get('/categories/:id', getCategory);
router.put('/categories/:id', protect, upload.single('image'), updateCategory);
router.delete('/categories/:id', protect, deleteCategory);

// Type routes
router.post('/types', protect, createType);

router.get('/types', getTypes);
router.get('/types/category/:categoryId', getTypesByCategory);
router.get('/types/:id', getType);
router.put('/types/:id', protect, updateType);
router.delete('/types/:id', protect, deleteType);

// Plate routes with image upload
router.post('/plates', protect, upload.single('image'), createPlate);
router.put('/plates/:plateId/image', protect, upload.single('image'), uploadImagePlate);
router.get('/plates/:cityId', getPlates);
router.get('/plates/type/:typeId', getPlatesByType);
router.get('/plates/:id', getPlate);
router.put('/plates/:id', protect, upload.single('image'), updatePlate);
router.delete('/plates/:id', protect, deletePlate);

export default router;