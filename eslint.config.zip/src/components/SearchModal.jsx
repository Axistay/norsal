"use client"

import { useState, useEffect } from "react"
import { useNavigate, useParams } from "react-router-dom"
import { useTranslation } from "react-i18next"
import { useSelector } from "react-redux"
import { X, Search } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

const SearchModal = ({ isOpen, onClose, searchTerm }) => {
  const { t, i18n } = useTranslation()
  const langUsed = i18n.language
  const navigate = useNavigate()
  const { cityId } = useParams()
  
  // Get data from Redux store
  const { plates, categories, types } = useSelector((state) => state.menu)
  
  const [results, setResults] = useState([])
  const [categoryCounts, setCategoryCounts] = useState({})

  useEffect(() => {
    if (!searchTerm || searchTerm.trim() === "") {
      setResults([])
      setCategoryCounts({})
      return
    }

    // Filter plates based on search term in all languages
    const filteredResults = plates.filter((plate) => {
      const searchTermLower = searchTerm.toLowerCase()
      
      // Check title in all languages
      const titleMatch = Object.values(plate?.title || {}).some(
        (value) => value && value.toLowerCase().includes(searchTermLower)
      )
      
      // Check description in all languages
      const descriptionMatch = Object.values(plate?.description || {}).some(
        (value) => value && value.toLowerCase().includes(searchTermLower)
      )
      
      return titleMatch || descriptionMatch
    })

    // Build a map of types to categories for faster lookup
    const typeToCategoryMap = {}
    types.forEach(type => {
      if (type._id) {
        // Handle the case where categoryId is a string or an object
        const categoryId = typeof type.categoryId === 'object' ? 
          type.categoryId._id?.toString() : 
          type.categoryId?.toString()
          
        if (categoryId) {
          typeToCategoryMap[type._id.toString()] = categoryId
        }
      }
    })
    
    // Get counts by category using the map
    const counts = {}
    
    filteredResults.forEach((plate) => {
      if (!plate.typeId) return
      
      // Handle the case where typeId is a string or an object
      const typeId = typeof plate.typeId === 'object' ? 
        plate.typeId._id?.toString() : 
        plate.typeId?.toString()
        
      if (!typeId) return
      
      const categoryId = typeToCategoryMap[typeId]
      
      if (!categoryId) return
      
      // Increment category count
      counts[categoryId] = (counts[categoryId] || 0) + 1
    })

    setCategoryCounts(counts)
    setResults(filteredResults.slice(0, 5)) // Show only 5 results
  }, [searchTerm, plates, types])

  const handlePlateClick = (id) => {
    navigate(`/${cityId}/menu/category/plate/${id}`)
    onClose()
  }
  
  const handleCategoryClick = (categoryId) => {
    navigate(`/${cityId}/menu/category/${categoryId}`)
    onClose()
  }

  // Get category associated with a plate through its typeId
  const getPlateCategory = (plate) => {
    if (!plate?.typeId) return null
    
    // Handle the case where typeId is a string or an object
    const typeId = typeof plate.typeId === 'object' ? 
      plate.typeId._id?.toString() : 
      plate.typeId?.toString()
      
    if (!typeId) return null
    
    const type = types.find(t => {
      const tId = t._id?.toString?.() || t._id
      return tId === typeId
    })
    
    if (!type?.categoryId) return null
    
    // Handle the case where categoryId is a string or an object
    const categoryId = typeof type.categoryId === 'object' ? 
      type.categoryId._id?.toString() : 
      type.categoryId?.toString()
      
    if (!categoryId) return null
    
    return categories.find(c => {
      const cId = c._id?.toString?.() || c._id
      return cId === categoryId
    })
  }

  // Get display name for the category
  const getCategoryName = (categoryId) => {
    const category = categories.find((c) => {
      const cId = c._id?.toString?.() || c._id
      return cId === categoryId
    })
    return category?.name?.[langUsed] || 'Unknown Category'
  }

  // Get category image
  const getCategoryImage = (categoryId) => {
    const category = categories.find((c) => {
      const cId = c._id?.toString?.() || c._id
      return cId === categoryId
    })
    return category?.image?.url || "/placeholder.svg"
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: 50, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.9, y: 50, opacity: 0 }}
            transition={{ type: "spring", duration: 0.5 }}
            className="bg-teal-100 dark:bg-gray-800 rounded-xl relative   p-5 max-h-[80vh] overflow-y-auto shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold dark:text-white">{t("search.results")}</h2>
              <button 
                onClick={onClose} 
                className="p-1 rounded-full hover:scale-110 bg-teal-900 text-white transition-colors"
                aria-label="Close search"
              >
                <X size={24} />
              </button>
            </div>

            {/* No results state */}
            {(results.length === 0 && searchTerm.trim() !== "") && (
              <div className="flex flex-col items-center justify-center py-8">
                <Search size={48} className="text-gray-300 mb-4" />
                <p className="text-gray-500 dark:text-gray-400 text-center">{t("search.no_results")}</p>
              </div>
            )}

            {/* Result list */}
            {results.length > 0 && (
              <div className="space-y-4">
                {results.map((plate) => {
                  const category = getPlateCategory(plate)
                  
                  return (
                    <div
                      key={plate?._id}
                      onClick={() => handlePlateClick(plate?._id)}
                      className="flex items-center space-x-3 p-2 rounded-lg cursor-pointer hover:bg-gray-100 bg-teal-50"
                    >
                      <img
                        src={plate?.image?.url || "/placeholder.svg"}
                        alt={plate?.title?.[langUsed] || ""}
                        className="w-16 h-16 object-cover rounded-lg"
                        loading="lazy"
                      />
                      <div className="flex-1 px-4">
                        <h3 className="font-medium dark:text-white">{plate?.title?.[langUsed]}</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-1">
                          {plate?.description?.[langUsed]}
                        </p>
                        <div className="flex justify-between items-center mt-1">
                          <p className="text-blue-600 dark:text-blue-400 text-sm">
                            {plate?.price?.toFixed(2)} MAD
                          </p>
                          {category && (
                            <span className="text-xs bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded-full">
                              {category.name?.[langUsed]}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}

            {/* Categories with counts */}
            {Object.keys(categoryCounts).length > 0 && (
              <div className="mt-6">
                <h3 className="font-medium dark:text-white mb-2">{t("search.categories")}</h3>
                <div className="space-y-2">
                  {Object.entries(categoryCounts).map(([categoryId, count]) => (
                    <div
                      key={categoryId}
                      onClick={() => handleCategoryClick(categoryId)}
                      className="flex items-center justify-between p-2 rounded-lg cursor-pointer hover:bg-teal-200/70 bg-teal-200/50"
                    >
                      <div className="flex items-center">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center mr-2">
                          <img
                            src={getCategoryImage(categoryId)}
                            alt={getCategoryName(categoryId)}
                            className="w-5 h-5 object-contain"
                            loading="lazy"
                          />
                        </div>
                        <span className="dark:text-white">{getCategoryName(categoryId)}</span>
                      </div>
                      <span className="bg-gray-200 dark:bg-gray-600 rounded-full px-2 py-1 text-xs dark:text-white">
                        {count}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export default SearchModal