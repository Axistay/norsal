"use client";

import React, { useState, useCallback } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch } from "react-redux";
import { motion, AnimatePresence } from "framer-motion";
import { addToCart } from "../redux/slices/cartSlice";
import PlateDetail from "../pages/PlateDetail";
import { Expand, Loader2 } from "lucide-react";

 
const PlateCard = ({ plate }) => {
  // Hooks
  const { t, i18n } = useTranslation();
  const dispatch = useDispatch();
  
  // State management
  const [showDetail, setShowDetail] = useState(false);
  const [imageLoading, setImageLoading] = useState(true);
  
  // Derived values
  const currentLanguage = i18n.language;
  const plateTitle = plate?.title?.[currentLanguage] || "";
  const plateDescription = plate?.description?.[currentLanguage] || "";
  const platePrice = plate?.price || 0;
  const plateImage = plate?.image?.url || "/placeholder.svg";

  // Event handlers
  const handleToggleDetail = useCallback(() => {
    setShowDetail(prev => !prev);
  }, []);

  const handleAddToCart = useCallback((event) => {
    event.preventDefault();
    event.stopPropagation();
    dispatch(addToCart(plate));
  }, [dispatch, plate]);

  const handleImageLoad = useCallback(() => {
    setImageLoading(false);
  }, []);

  const handleCloseDetail = useCallback((isOpen) => {
    setShowDetail(isOpen);
  }, []);

  // Animation variants
  const cardVariants = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -20 }
  };

  // Early return for invalid plate data
  if (!plate) {
    return null;
  }

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      transition={{ duration: 0.3, ease: "easeOut" }}
      className="card mb-4 overflow-hidden hover:shadow-lg transition-shadow duration-300"
    >
      <div
        onClick={handleToggleDetail}
        className="block cursor-pointer group"
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleToggleDetail();
          }
        }}
        aria-label={`View details for ${plateTitle}`}
      >
        {/* Image Section */}
        <div className="relative overflow-hidden">
          {imageLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-100 z-10">
              <Loader2 
                className="h-8 w-8 animate-spin text-gray-500" 
                aria-label="Loading image"
              />
            </div>
          )}
          
          <img
            src={plateImage}
            alt={plateTitle}
            className={`w-full h-48 object-cover transition-all duration-300 group-hover:scale-105 ${
              imageLoading ? 'opacity-0' : 'opacity-100'
            }`}
            loading="lazy"
            onLoad={handleImageLoad}
            onError={(e) => {
              e.target.src = "/placeholder.svg";
              setImageLoading(false);
            }}
          />
          
          {/* Overlay for better text visibility */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </div>

        {/* Content Section */}
        <div className="p-4">
          <h3 className="font-bold text-lg text-gray-900 mb-2 line-clamp-1">
            {plateTitle}
          </h3>
          
          <p className="text-gray-600 text-sm leading-relaxed line-clamp-2 mb-4">
            {plateDescription}
          </p>
          
          <div className="flex justify-between items-center">
            <span className="font-bold text-lg text-primary">
              {platePrice.toFixed(2)} MAD
            </span>
            
            <button
              className="text-white bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 rounded text-sm py-2 px-3 flex items-center gap-2 hover:transform hover:scale-105 transition-transform duration-200"
              onClick={(e) => {
                e.stopPropagation();
                handleToggleDetail();
              }}
              aria-label={`Expand details for ${plateTitle}`}
            >
              <Expand className="h-4 w-4" />
              <span className="hidden sm:inline">{t('common.viewDetails', 'View Details')}</span>
            </button>
          </div>
        </div>
      </div>
      
      {/* Detail Modal */}
      <AnimatePresence mode="wait">
        {showDetail && (
          <PlateDetail 
            dataPlate={plate} 
            onClose={handleCloseDetail}
          />
        )}
      </AnimatePresence>
    </motion.div>
  );
};

// PropTypes for better development experience (optional)
PlateCard.displayName = 'PlateCard';

export default React.memo(PlateCard);