"use client"
import { useTranslation } from "react-i18next"
import { useSelector, useDispatch } from "react-redux"
import { Link, useNavigate } from "react-router-dom"
import { Trash2, ShoppingBag } from "lucide-react"
import { motion } from "framer-motion"

import { removeFromCart, updateQuantity } from "../redux/slices/cartSlice"
import { Layout } from "../layout/layout"

const Cart = () => {
  const { t, i18n } = useTranslation()
  const langused = i18n.language

  const dispatch = useDispatch()
  const { items, total } = useSelector((state) => state.cart)
  const navigate = useNavigate()

  const handleRemoveItem = (id) => {
    dispatch(removeFromCart(id))
  }

  const handleQuantityChange = (id, quantity) => {
    if (quantity < 1) return
    dispatch(updateQuantity({ _id: id, quantity }))
  }

  const cityId = localStorage.getItem('selectedCity')
  const handleGenerateQRCode = () => {
    navigate("/cart/qr", {
      state: {
        items: items.map((item) => ({
          id: item._id,
          title: item.title?.[langused] || item.name || 'Unknown Item',
          quantity: item.quantity,
          price: item.price,
        })),
        total,
        cityId
      },
    })
  }

  return (
    <Layout>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="pb-20 px-4"
      >
        <div className="pt-16">
          <h1 className="text-2xl font-bold mb-6">{t("cart.title")}</h1>

          {items.length === 0 ? (
            <div className="text-center py-10">
              <ShoppingBag className="w-16 h-16 mx-auto text-gray-300" />
              <p className="mt-4 text-gray-500">{t("cart.empty")}</p>
              <Link to="/" className="btn-primary mt-4 inline-block">
                {t("cart.continueShopping")}
              </Link>
            </div>
          ) : (
            <>
              <div className="grid gap-6 md:grid-cols-2">
                {items.map((item) => (
                  <div
                    key={item._id}
                    className="bg-white rounded-xl p-4 shadow-sm flex items-center"
                  >
                    <img
                      src={item.image || "/placeholder.svg"}
                      alt={item.title?.[langused] || item.name || 'Item'}
                      className="w-20 h-20 object-cover rounded-lg me-4"
                    />

                    <div className="flex-grow">
                      <div className="flex justify-between">
                        <h3 className="font-medium">
                          {item.title?.[langused] || item.name || 'Unknown Item'}
                        </h3>
                        <button
                          onClick={() => handleRemoveItem(item._id)}
                          className="text-red-500"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>

                      <p className="text-gray-500 text-sm mt-1">
                        {item.price.toFixed(2)} MAD
                      </p>

                      <div className="flex justify-between items-center mt-3">
                        <div className="flex items-center border rounded-lg">
                          <button
                            onClick={() =>
                              handleQuantityChange(item._id, item.quantity - 1)
                            }
                            className="px-3 py-1 text-gray-600"
                          >
                            -
                          </button>
                          <span className="px-3 py-1">{item.quantity}</span>
                          <button
                            onClick={() =>
                              handleQuantityChange(item._id, item.quantity + 1)
                            }
                            className="px-3 py-1 text-gray-600"
                          >
                            +
                          </button>
                        </div>

                        <span className="font-medium">
                          {(item.price * item.quantity).toFixed(2)} MAD
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-8 bg-white rounded-xl p-4 shadow-sm">
                <div className="flex justify-between mb-2">
                  <span className="text-gray-600">{t("cart.total")}</span>
                  <span className="font-medium">{total.toFixed(2)} MAD</span>
                </div>

                <button
                  onClick={handleGenerateQRCode}
                  className="btn-secondary w-full mt-2"
                >
                  {t("cart.checkout") || "Generate QR Code"}
                </button>
              </div>
            </>
          )}
        </div>
      </motion.div>
    </Layout>
  )
}

export default Cart