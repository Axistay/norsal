"use client"

import { useEffect, useState } from "react"
import { useParams } from "react-router-dom"
import { useTranslation } from "react-i18next"
import { useSelector, useDispatch } from "react-redux"
import { motion } from "framer-motion"

import { setCurrentCategory, setInitialMenuData } from "../redux/slices/menuSlice"
import CategoryNavbar from "../components/CategoryNavbar"
import PlateCard from "../components/PlateCard"
import { Layout } from "../layout/layout"
import { loadMenuData } from "../utils/loadMenuData"

const CategoryMenu = () => {
  const { id } = useParams()
  const { t, i18n } = useTranslation()
  const dispatch = useDispatch();

  const selectedCity = localStorage.getItem('selectedCity')
  useEffect(() => {
    async function initMenu() {
      const menuData = await loadMenuData();
      dispatch(setInitialMenuData(menuData));
    }
    initMenu();
  }, [selectedCity]);
  const langUsed = i18n.language
  const categoryId = id // MongoDB ObjectId is already a string

  const { categories, types, plates } = useSelector((state) => state.menu)
  const currentCategory = categories.find((cat) => cat._id === categoryId)

  const [activeType, setActiveType] = useState(null)
  const [categoryTypes, setCategoryTypes] = useState([])
  const [typedPlates, setTypedPlates] = useState({})

  useEffect(() => {
    if (currentCategory) {
      // Filter types by category ID
      const filteredTypes = types.filter((type) => 
        type.categoryId === categoryId || 
        (type.categoryId && type.categoryId._id === categoryId)
      )
      
      setCategoryTypes(filteredTypes)

      if (filteredTypes?.length > 0 && !activeType) {
        setActiveType(filteredTypes[0]._id) // Use _id instead of id
      }

      // Group plates by type
      const platesMap = {}
      plates
        .filter((plate) => {
          return plate.typeId && (
            (typeof plate.typeId === 'string' && filteredTypes.some(type => type._id === plate.typeId)) || 
            (plate.typeId._id && filteredTypes.some(type => type._id === plate.typeId._id))
          )
        })
        .forEach((plate) => {
          const typeId = typeof plate.typeId === 'string' ? plate.typeId : plate.typeId._id
          if (!platesMap[typeId]) {
            platesMap[typeId] = []
          }
          platesMap[typeId].push(plate)
        })

      setTypedPlates(platesMap)
      dispatch(setCurrentCategory(categoryId))
    }
  }, [categoryId, currentCategory, types, plates, dispatch, activeType])

  if (!currentCategory) return <div>Loading...</div>

  return (
    <Layout>
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        exit={{ opacity: 0 }} 
        className="pb-20 px-4"
      >
        <div className="mt-32 pb-4">
          <div className="relative mb-6">
            <img
              src={currentCategory.image?.url || "/placeholder.svg"}
              alt={currentCategory.name[langUsed]}
              className="w-full h-40 object-cover rounded-xl"
            />
            <div className="absolute inset-0 flex-col bg-black/50 rounded-xl flex items-center justify-center">
              <h1 className="text-white text-3xl font-bold">{currentCategory.name[langUsed]}</h1>
              <h1 className="text-teal-300 max-w-screen text-md font-bold">{currentCategory?.description[langUsed]}</h1>
            </div>
          </div>

          {/* Type Navigation */}
          {categoryTypes?.length > 0 && (
            <CategoryNavbar 
              types={categoryTypes} 
              activeType={activeType} 
              setActiveType={setActiveType} 
            />
          )}

          {/* Render plates by type */}
          <div className="pt-16">
            {categoryTypes?.map((type) => (
              <div key={type._id} id={`type-${type._id}`} className="mb-10">
                <h2 className="font-bold text-xl mb-4 bg-[#ffd699] text-center rounded">
                  {type.name[langUsed]}
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {typedPlates[type._id]?.map((plate) => (
                    <PlateCard key={plate._id} plate={plate} />
                  ))}
                </div>
                {!typedPlates[type._id] || typedPlates[type._id].length === 0 ? (
                  <div className="text-center py-4">
                    <p className="text-gray-500">{t('search.noItemsAvailable')}</p>
                  </div>
                ) : null}
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    </Layout>
  )
}

export default CategoryMenu