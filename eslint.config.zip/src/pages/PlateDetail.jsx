"use client"

import React, { useMemo, useEffect, useCallback, useState } from "react"
import { useTranslation } from "react-i18next"
import { useSelector, useDispatch } from "react-redux"
import { ShoppingCart, X, Clock, Users, ZoomIn } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { addToCart, removeFromCart } from "../redux/slices/cartSlice"
import { Layout } from "../layout/layout"
import { useNavigate, useParams } from "react-router-dom"

// Animation constants
const ANIMATION_DURATION = {
  FAST: 0.2,
  MEDIUM: 0.4,
  SLOW: 0.6
}

const ANIMATION_VARIANTS = {
  backdrop: {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { duration: ANIMATION_DURATION.FAST }
    },
    exit: { 
      opacity: 0,
      transition: { duration: ANIMATION_DURATION.FAST }
    }
  },
  modal: {
    hidden: { 
      y: 50, 
      opacity: 0,
      scale: 0.95
    },
    visible: { 
      y: 0, 
      opacity: 1,
      scale: 1,
      transition: { 
        type: "spring", 
        damping: 25,
        stiffness: 300,
        duration: ANIMATION_DURATION.MEDIUM
      }
    },
    exit: { 
      y: 50,
      opacity: 0,
      scale: 0.95,
      transition: { duration: ANIMATION_DURATION.FAST }
    }
  },
  imageViewer: {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { duration: ANIMATION_DURATION.MEDIUM }
    },
    exit: { 
      opacity: 0,
      transition: { duration: ANIMATION_DURATION.MEDIUM }
    }
  },
  imageScale: {
    hidden: { scale: 0.8, opacity: 0 },
    visible: { 
      scale: 1, 
      opacity: 1,
      transition: { 
        type: "spring", 
        damping: 20,
        stiffness: 300,
        duration: ANIMATION_DURATION.SLOW
      }
    },
    exit: { 
      scale: 0.8,
      opacity: 0,
      transition: { duration: ANIMATION_DURATION.MEDIUM }
    }
  },
  slideIn: {
    hidden: { opacity: 0, y: 20 },
    visible: (delay = 0) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay,
        duration: ANIMATION_DURATION.MEDIUM,
        ease: "easeOut"
      }
    })
  },
  button: {
    hover: { 
      scale: 1.02,
      transition: { duration: 0.2 }
    },
    tap: { scale: 0.98 }
  }
}

// Full-Screen Image Viewer Component
const FullScreenImageViewer = ({ src, alt, isOpen, onClose }) => {
  const handleKeyDown = useCallback((event) => {
    if (event.key === 'Escape') {
      onClose()
    }
  }, [onClose])

  useEffect(() => {
    if (isOpen) {
      document.addEventListener('keydown', handleKeyDown)
      document.body.style.overflow = 'hidden'
    }
    
    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      if (isOpen) {
        document.body.style.overflow = 'unset'
      }
    }
  }, [isOpen, handleKeyDown])

  if (!isOpen) return null

  return (
    <AnimatePresence>
      <motion.div
        variants={ANIMATION_VARIANTS.imageViewer}
        initial="hidden"
        animate="visible"
        exit="exit"
        className="fixed inset-0 z-[60] bg-black bg-opacity-95 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={onClose}
      >
        {/* Close button */}
        <motion.button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 bg-white bg-opacity-20 hover:bg-opacity-30 p-3 rounded-full transition-all duration-200 backdrop-blur-sm"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
        >
          <X className="w-6 h-6 text-white" />
        </motion.button>

        {/* Full-screen image */}
        <motion.div
          variants={ANIMATION_VARIANTS.imageScale}
          className="max-w-full max-h-full"
          onClick={(e) => e.stopPropagation()}
        >
          <img
            src={src}
            alt={alt}
            className="max-w-full max-h-full object-contain rounded-lg shadow-2xl"
            style={{ maxHeight: 'calc(100vh - 2rem)' }}
          />
        </motion.div>

        {/* Image info overlay */}
        <motion.div
          className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-50 backdrop-blur-sm px-4 py-2 rounded-full"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <p className="text-white text-sm font-medium">{alt}</p>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}

// Nutrition circle component
const NutritionCircle = ({ label, value, maxValue, color, delay }) => (
  <motion.div 
    className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay, duration: ANIMATION_DURATION.MEDIUM }}
  >
    <div className="flex items-center justify-between mb-2">
      <span className="text-gray-600 text-sm font-medium">{label}</span>
      <div className="relative w-12 h-12">
        <svg className="w-12 h-12 transform -rotate-90">
          <circle 
            cx="24" 
            cy="24" 
            r="18" 
            fill="none" 
            stroke="#f3f4f6" 
            strokeWidth="3" 
          />
          <motion.circle
            cx="24"
            cy="24"
            r="18"
            fill="none"
            stroke={color}
            strokeWidth="3"
            strokeDasharray={`${2 * Math.PI * 18}`}
            strokeDashoffset={`${2 * Math.PI * 18 * (1 - (value || 0) / maxValue)}`}
            initial={{ strokeDashoffset: `${2 * Math.PI * 18}` }}
            animate={{ strokeDashoffset: `${2 * Math.PI * 18 * (1 - (value || 0) / maxValue)}` }}
            transition={{ delay: delay + 0.3, duration: 1, ease: "easeOut" }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.span
            className="text-sm font-semibold text-gray-800"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: delay + 0.5 }}
          >
            {value || 0}
          </motion.span>
        </div>
      </div>
    </div>
    
  </motion.div>
)

const PlateDetail = ({ dataPlate, onClose }) => {
  const { plateId } = useParams()
  const id = plateId || dataPlate?._id 
  const { t, i18n } = useTranslation()
  const langUsed = i18n.language
  const dispatch = useDispatch()
  const navigate = useNavigate()
  
  // State for full-screen image viewer
  const [isImageViewerOpen, setIsImageViewerOpen] = useState(false)

  // Redux selectors
  const { plates } = useSelector((state) => state.menu)
  const cartItems = useSelector((state) => state.cart.items)
  
  // Memoized values
  const plate = useMemo(() => 
    plates.find((p) => p?._id === id), 
    [plates, id]
  )
  
  const isInCart = useMemo(() => 
    cartItems.some((item) => item?._id === plate?._id), 
    [cartItems, plate?._id]
  )

  // Handlers
  const handleClose = useCallback(() => {
    if (typeof onClose === 'function') {
      onClose()
    } else {
      navigate(-1)
    }
  }, [onClose, navigate])

  const handleAddToCart = useCallback(() => {
    if (!plate) return
    
    if (isInCart) {
      dispatch(removeFromCart(plate._id))
    } else {
      dispatch(addToCart(plate))
    }
  }, [dispatch, plate, isInCart])

  const handleKeyDown = useCallback((event) => {
    if (event.key === 'Escape' && !isImageViewerOpen) {
      handleClose()
    }
  }, [handleClose, isImageViewerOpen])

  const handleImageClick = useCallback(() => {
    setIsImageViewerOpen(true)
  }, [])

  const handleCloseImageViewer = useCallback(() => {
    setIsImageViewerOpen(false)
  }, [])

  // Effects
  useEffect(() => {
    const originalStyle = window.getComputedStyle(document.body).overflow
    if (!isImageViewerOpen) {
      document.body.style.overflow = 'hidden'
    }
    document.addEventListener('keydown', handleKeyDown)
    
    return () => {
      if (!isImageViewerOpen) {
        document.body.style.overflow = originalStyle
      }
      document.removeEventListener('keydown', handleKeyDown)
    }
  }, [handleKeyDown, isImageViewerOpen])

  // Loading state
  if (!plate) {
    return (
      <Layout>
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white rounded-lg p-8 shadow-xl">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-teal-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">{t('common.loading', 'Loading...')}</p>
          </div>
        </div>
      </Layout>
    )
  }

  const nutrition = plate.nutrition || {}
  const isRTL = langUsed === 'ar'

  return (
    <Layout>
      <motion.div
        variants={ANIMATION_VARIANTS.backdrop}
        initial="hidden"
        animate="visible"
        exit="exit"
        className="fixed inset-0 z-50 bg-black bg-opacity-60 backdrop-blur-sm overflow-y-auto"
        onClick={handleClose}
      >
        <div className="min-h-screen px-4 py-8 flex items-center justify-center">
          <motion.div 
            variants={ANIMATION_VARIANTS.modal}
            className="max-w-4xl w-full bg-white rounded-2xl shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header with close button */}
            <div className="relative">
              <motion.button 
                onClick={handleClose}
                variants={ANIMATION_VARIANTS.button}
                whileHover="hover"
                whileTap="tap"
                className={`absolute top-4 z-10 bg-white hover:bg-gray-50 p-2 rounded-full shadow-lg transition-colors ${
                  isRTL ? 'left-4' : 'right-4'
                }`}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
                aria-label={t('common.close', 'Close')}
              >
                <X className="w-5 h-5 text-gray-600" />
              </motion.button>

              {/* Hero image with zoom functionality */}
              <motion.div 
                className="relative h-64 md:h-80 overflow-hidden cursor-pointer group"
                initial={{ opacity: 0, scale: 1.05 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6 }}
                onClick={handleImageClick}
              >
                <img
                  src={plate?.image?.url || "/placeholder.svg"}
                  alt={plate.title?.[langUsed] || plate.title?.en || 'Dish'}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                
                {/* Zoom indicator */}
                <motion.div
                  className={`absolute top-4 ${langUsed === 'ar' ? 'right-4' : 'left-4'} bg-black bg-opacity-50 backdrop-blur-sm p-2 rounded-full opacity-100  transition-opacity duration-200`}
                  whileHover={{ scale: 1.1 }}
                >
                  <ZoomIn className="w-5 h-5 text-white" />
                </motion.div>

                {/* Click hint */}
                <motion.div
                  className="absolute bottom-4 right-4 bg-black bg-opacity-50 backdrop-blur-sm px-3 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                  initial={{ opacity: 0, y: 10 }}
                  whileHover={{ opacity: 1, y: 0 }}
                >
                  <span className="text-white text-sm font-medium">
                    {t('common.clickToZoom', 'Click to zoom')}
                  </span>
                </motion.div>
              </motion.div>
            </div>

            {/* Content */}
            <div className="p-6 md:p-8">
              {/* Title section */}
              <motion.div 
                custom={0.1}
                variants={ANIMATION_VARIANTS.slideIn}
                initial="hidden"
                animate="visible"
                className="mb-6"
              >
                <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
                  {plate.title?.[langUsed] || plate.title?.en || 'Untitled Dish'}
                </h1>
                <motion.div 
                  className="h-1 w-16 bg-teal-500 rounded"
                  initial={{ width: 0 }}
                  animate={{ width: "4rem" }}
                  transition={{ delay: 0.4, duration: 0.5 }}
                />
              </motion.div>

              {/* Description */}
              <motion.p 
                custom={0.2}
                variants={ANIMATION_VARIANTS.slideIn}
                initial="hidden"
                animate="visible"
                className="text-gray-600 leading-relaxed mb-8"
              >
                {plate.description?.[langUsed] || plate.description?.en || 'No description available.'}
              </motion.p>

              {/* Nutrition information */}
              <motion.div 
                custom={0.3}
                variants={ANIMATION_VARIANTS.slideIn}
                initial="hidden"
                animate="visible"
                className="mb-8"
              >
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  {t("menu.nutritionalInfo", "Nutritional Information")}
                </h3>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <NutritionCircle
                    label={t("menu.calories", "Calories")}
                    value={nutrition.calories}
                    maxValue={800}
                    color="#10b981"
                    delay={0.5}
                  />
                  <NutritionCircle
                    label={t("menu.protein", "Protein")}
                    value={nutrition.protein}
                    maxValue={50}
                    color="#3b82f6"
                    delay={0.6}
                  />
                  <NutritionCircle
                    label={t("menu.carbs", "Carbs")}
                    value={nutrition.carbs}
                    maxValue={100}
                    color="#f59e0b"
                    delay={0.7}
                  />
                  <NutritionCircle
                    label={t("menu.fat", "Fat")}
                    value={nutrition.fat}
                    maxValue={50}
                    color="#ef4444"
                    delay={0.8}
                  />
                </div>
              </motion.div>

              {/* Additional info */}
              {(plate.cookingTime || plate.servings) && (
                <motion.div
                  custom={0.4}
                  variants={ANIMATION_VARIANTS.slideIn}
                  initial="hidden"
                  animate="visible"
                  className="flex gap-6 mb-8 text-sm text-gray-600"
                >
                  {plate.cookingTime && (
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      <span>{plate.cookingTime} {t("common.minutes", "min")}</span>
                    </div>
                  )}
                  {plate.servings && (
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      <span>{plate.servings} {t("common.servings", "servings")}</span>
                    </div>
                  )}
                </motion.div>
              )}

              {/* Price and cart section */}
              <motion.div 
                custom={0.5}
                variants={ANIMATION_VARIANTS.slideIn}
                initial="hidden"
                animate="visible"
                className="flex items-center justify-between pt-6 border-t border-gray-100"
              >
                <div>
                  <p className="text-sm text-gray-500 mb-1">{t("menu.price", "Price")}</p>
                  <motion.p 
                    className="text-2xl font-bold text-gray-900"
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.8 }}
                  >
                    {typeof plate.price === 'number' ? plate.price.toFixed(2) : '0.00'} MAD
                  </motion.p>
                </div>
                
                <motion.button
                  onClick={handleAddToCart}
                  variants={ANIMATION_VARIANTS.button}
                  whileHover="hover"
                  whileTap="tap"
                  className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 flex items-center gap-2 ${
                    isInCart 
                      ? "bg-green-600 hover:bg-green-700 text-white" 
                      : "bg-teal-600 hover:bg-teal-700 text-white"
                  }`}
                  disabled={!plate}
                >
                  <motion.div
                    animate={{ 
                      rotate: isInCart ? 0 : [0, -5, 5, -5, 5, 0] 
                    }}
                    transition={{ delay: 1, duration: 0.4 }}
                  >
                    <ShoppingCart className="w-5 h-5" />
                  </motion.div>
                  {isInCart 
                    ? t("menu.inToCart", "In Cart") 
                    : t("menu.addToCart", "Add to Cart")
                  }
                </motion.button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </motion.div>

      {/* Full-Screen Image Viewer */}
      <FullScreenImageViewer
        src={plate?.image?.url || "/placeholder.svg"}
        alt={plate.title?.[langUsed] || plate.title?.en || 'Dish'}
        isOpen={isImageViewerOpen}
        onClose={handleCloseImageViewer}
      />
    </Layout>
  )
}

export default PlateDetail