import { categoryApi, plateApi, typeApi } from "../lib/api";

const cityID = localStorage.getItem("selectedCity");


const dataCat = async()=>{
  const categories = await categoryApi.getByCity(cityID);
  return categories
}

const dataType = async()=>{
  const types = await typeApi.getAll();
  return types
}

const dataPlate = async()=>{
  const paltes = await plateApi.getAll();
  return paltes
}




export const menuData = {
  categories: await dataCat(),
  types: await dataType(),
  plates: await dataPlate()
};
