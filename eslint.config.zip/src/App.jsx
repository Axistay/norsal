"use client"

import { Routes, Route, useLocation } from "react-router-dom"
import { AnimatePresence } from "framer-motion"

// Pages
import Home from "./pages/Home"
import CategoryMenu from "./pages/CategoryMenu"
import PlateDetail from "./pages/PlateDetail"
import Language from "./pages/Language"

// Components
import Footer from "./components/Footer"
import BackButton from "./components/BackButton"
import MenuModal from "./pages/MenuPage"
import CitySelection from "./pages"
import { loadMenuData } from "./utils/loadMenuData"
import { setInitialMenuData } from "./redux/slices/menuSlice"
import SimplifiedCitySelector from "./components/ModuleSelectCity"
// import CartSummary from "./pages/cart-summary"
import Cart from "./pages/Cart"
import CartQRCode from "./components/qrcode-generate"
import LoginPage from "./admin/login/page"
import DashboardPage from "./admin/dashboard/page"
import DashboardUsers from "./admin/dashboard/users/page"
// Restaurant data for our 3 cities
const cities = [
  {
    id: "nador",
    name: {
      en: "Nador",
      es: "Nador",
      fr: "Nador",
      ar: "الناظور"
    },
    image: "https://agencemarchica.gov.ma/wp-content/uploads/2016/10/IMG3-6.jpg",
    border: "border-teal-500",
    bg: "bg-teal-300"
  },
  {
    id: "al_hoceima",
    name: {
      en: "Al Hoceima",
      es: "Alhucemas",
      fr: "Al Hoceïma",
      ar: "الحسيمة"
    },
    image: "https://ugc.zenchef.com/3/6/6/6/0/0/1/5/1/9/7/7/2/1723539197_152/ce1cd9e61c971553a82684889b7e3b0f.website.jpg",
    border: "border-orange-500",
    bg: "bg-orange-500"
  },
  {
    id: "tanger",
    name: {
      en: "Tangier",
      es: "Tánger",
      fr: "Tanger",
      ar: "طنجة"
    },
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS76Wf0kqllUWqsEtP-UvVgyDT_BcjM4StMeQ&s",
    border: "border-blue-500",
    bg: "bg-blue-500"
  },
  {
    id: "",
    name: {
      en: "Coming Soon",
      es: "Próximamente",
      fr: "Prochainement",
      ar: "قريباً"
    },
    image: "https://agencemarchica.gov.ma/wp-content/uploads/2016/10/IMG3-6.jpg",
    border: "border-blue-500",
    bg: "bg-black"
  }
];


const App = () => {

  // det data


  

  const location = useLocation()

  const storedCityId = localStorage.getItem('selectedCity');

  if ((!storedCityId || storedCityId === 'select') && location.pathname !== "/") {
    return (
      <>
        <SimplifiedCitySelector cities={cities} />
      </>
    )
  }

  return (
    <>
          <AnimatePresence mode="wait">
            <Routes location={location} key={location.pathname}>
              <Route path="/" element={<CitySelection cities={cities} />} />
              <Route path="/:cityId/menu" element={<Home cities={cities} />} />
              <Route path="/:cityId/menu/category/:id" element={<CategoryMenu />} />
              <Route path="/:cityId/menu/category/plate/:plateId" element={<PlateDetail />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/language" element={<Language />} />
              {/* <Route path="/summary" element={<CartSummary />} /> */}
              <Route path="/cart/qr" element={<CartQRCode />} />
              <Route path="/admin/login" element={<LoginPage cities={cities} />} />
              <Route path="/admin" element={<LoginPage  />} />
            <Route path="/admin/dashboard" element={<DashboardPage cities={cities} type={'categories'}  />} />
            <Route path="/admin/dashboard/:cityId" element={<DashboardPage cities={cities} type={'categories'}  />} />
            <Route path="/admin/dashboard/:cityId/category/:id" element={<DashboardPage type={'types'} cities={cities} />} />
            <Route path="/admin/dashboard/:cityId/category/:id/type/:typeId" element={<DashboardPage type={'plates'} cities={cities} />} />
            <Route path="/admin/dashboard/users" element={<DashboardPage type={'users'} />} />
            </Routes>
          </AnimatePresence>
       

    </>
  )
}

export default App
