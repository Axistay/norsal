// src/utils/loadMenuData.js
'../data/'
import { categoryApi, plateApi, typeApi } from "../lib/api";

export async function loadMenuData() {
  const cityID = localStorage.getItem("selectedCity");


  const dataCat = async()=>{
    const categories = await categoryApi.getByCity(cityID);
    return categories
  }
  
  const dataType = async()=>{
    const types = await typeApi.getAll();
    return types
  }
  
  const dataPlate = async()=>{
    const paltes = await plateApi.getAll(cityID);
    return paltes
  }

  
 const menuData = {
  categories: await dataCat(),
  types: await dataType(),
  plates: await dataPlate()
};
  
  return menuData;

}







