import React from 'react'
import BackButton from '../components/BackButton'
import Footer from '../components/Footer'
import { useLocation } from 'react-router-dom'

export const Layout = ({ children }) => {
    const location = useLocation()
  const storedCityId = localStorage.getItem('selectedCity');

    const showBackButton = location.pathname !== "/" && location.pathname !== `/${storedCityId}/menu`

    return (
        <>
            <div className="flex flex-col  min-h-screen h-full md:items-center md:justify-center bg-teal-100  "> 
            {/* bg-gradient-to-tr from-[#ffd699] via-[#a3ffff] to-[#004d4d]  */}
                <div className="flex-grow md:ps-20 lg:ps-0 pb-16 md:pb-0 md:max-w-5xl w-full shadow-teal-200 shadow-xl">
                    {showBackButton && <BackButton />}
                    {children}

                </div>
                <Footer />
            </div>
        </>
    )
}
