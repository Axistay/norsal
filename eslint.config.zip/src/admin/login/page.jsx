"use client"
import { useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { useTranslation } from "react-i18next"
import { useAuth } from "../../context/AuthContext"
import { Eye, EyeOff } from "lucide-react"

export default function LoginPage() {
  const { login, user } = useAuth()
  const { t, i18n } = useTranslation()
  const langused = i18n.language
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const navigate = useNavigate()
  if(user){
    navigate('/admin/dashboard')
  }

  // Translation object based on current language
  const translations = {
    en: {
      menuDashboard: "Menu Dashboard",
      login: "Login",
      username: "Email",
      password: "Password",
      invalidCredentials: "Invalid email or password",
      loggingIn: "Logging in...",
    },
    ar: {
      menuDashboard: "لوحة قائمة الطعام",
      login: "تسجيل الدخول",
      username: "البريد الإلكتروني",
      password: "كلمة المرور",
      invalidCredentials: "البريد الإلكتروني أو كلمة المرور غير صحيحة",
      loggingIn: "جاري تسجيل الدخول...",
    },
    fr: {
      menuDashboard: "Tableau de Bord Menu",
      login: "Connexion",
      username: "Email",
      password: "Mot de passe",
      invalidCredentials: "Email ou mot de passe invalide",
      loggingIn: "Connexion en cours...",
    },
    es: {
      menuDashboard: "Panel de Menú",
      login: "Iniciar Sesión",
      username: "Correo electrónico",
      password: "Contraseña",
      invalidCredentials: "Correo electrónico o contraseña inválidos",
      loggingIn: "Iniciando sesión...",
    }
  };
  

  // Get current language translations, fallback to English
  const currentTranslations = translations[langused] || translations.en

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    const response = await login(username, password)
    if (response.success) {
      navigate("/admin/dashboard")
    } else {
      setError(currentTranslations.invalidCredentials)
      setLoading(false)
    }
  }

  const changeLanguage = (lang) => {
    i18n.changeLanguage(lang)
  }

  return (
    <div className={`min-h-screen flex items-center justify-center bg-[#004d4d] p-4 ${langused === 'ar' ? 'rtl' : 'ltr'}`}>
      <div className="w-full max-w-md">
        {/* Language Selector */}
         

        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white">
            {currentTranslations.menuDashboard}
          </h1>
        </div>

        <div className="bg-white rounded-lg shadow-xl overflow-hidden border border-[#ffd699]">
          <div className="bg-[#ffd699] p-4">
            <h2 className="text-xl font-semibold text-[#004d4d] text-center">
              {currentTranslations.login}
            </h2>
          </div>
          <form onSubmit={handleSubmit} className="p-6 space-y-4" >
            <div className="space-y-2">
              <label htmlFor="username" className="block text-[#004d4d] font-medium">
                {currentTranslations.username}
              </label>
              <input
              dir="ltr"
                id="username"
                type="email"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                className="w-full px-3 py-2 border border-[#004d4d] rounded-md focus:outline-none focus:ring-2 focus:ring-[#ffd699]"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="password" className="block text-[#004d4d] font-medium">
                {currentTranslations.password}
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-[#004d4d] rounded-md focus:outline-none focus:ring-2 focus:ring-[#ffd699]"
                  dir={'ltr'}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#004d4d]"
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>
            {error && (
              <p className={`text-red-500 text-sm ${langused === 'ar' ? 'text-right' : 'text-left'}`}>
                {error}
              </p>
            )}
            <button
              type="submit"
              className="w-full py-2 px-4 bg-[#004d4d] hover:bg-[#003333] text-white font-medium rounded-md transition-colors"
              disabled={loading}
            >
              {loading ? currentTranslations.loggingIn : currentTranslations.login}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}