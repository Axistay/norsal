"use client"

import { useState, useEffect } from "react"
import { useTranslation } from "react-i18next"
import { userApi } from "../../../lib/api"

function DashboardContent() {
  const { t, i18n } = useTranslation()
  const dir = i18n.language === "ar" ? "rtl" : "ltr"
  const [users, setUsers] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [isResetPasswordModalOpen, setIsResetPasswordModalOpen] = useState(false)
  const [currentUser, setCurrentUser] = useState(null)
  const [searchTerm, setSearchTerm] = useState("")

  // Form state
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    role: "tanger",
  })
  const fetchUsers = async () => {
    try {
      const data = await userApi.getAll()
      setUsers(data.data)
    } catch (error) {
      console.error("Failed to fetch users:", error)
    } finally {
      setIsLoading(false)
    }
  }
  useEffect(() => {

    fetchUsers()
  }, [])


  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleAddUser = async (e) => {
    e.preventDefault()
    try {
      const newUser = await userApi.create(formData)
      setUsers([...users, newUser])
      setIsAddModalOpen(false)
      resetForm()
      fetchUsers()
    } catch (error) {
      console.error("Failed to add user:", error)
    }
  }

  const handleUpdateUser = async (e) => {
    e.preventDefault()
    if (!currentUser) return

    try {
      const newFormData = {
        email: formData.email,
        role: formData.role,
      }
      const updatedUser = await userApi.update(currentUser._id, newFormData)
      setUsers(users?.map((user) => (user._id === currentUser._id ? updatedUser : user)))
      setIsEditModalOpen(false)
      fetchUsers()
    } catch (error) {
      console.error("Failed to update user:", error)
    }
  }

  const handleDeleteUser = async () => {
    if (!currentUser) return

    try {
      await userApi.delete(currentUser._id)
      // setUsers(users?.filter((user) => user._id !== currentUser._id))
      setIsDeleteModalOpen(false)
      fetchUsers()
    } catch (error) {
      console.error("Failed to delete user:", error)
    }
  }

  const handleResetPassword = async (e) => {
    e.preventDefault()
    if (!currentUser) return

    try {
      await userApi.resetPassword({ email: currentUser.email, newPassword: formData.password })
      setIsResetPasswordModalOpen(false)
      alert('Updated sucess')
      fetchUsers()
      
    } catch (error) {
      console.error("Failed to reset password:", error)
    }
  }

  const openEditModal = (user) => {
    setCurrentUser(user)
    setFormData({
      email: user.email,
      password: "",
      role: user.role,
    })
    setIsEditModalOpen(true)
  }

  const openDeleteModal = (user) => {
    setCurrentUser(user)
    setIsDeleteModalOpen(true)
  }

  const openResetPasswordModal = (user) => {
    setCurrentUser(user)
    setFormData({
      ...formData,
      password: "",
    })
    setIsResetPasswordModalOpen(true)
  }

  const resetForm = () => {
    setFormData({
      email: "",
      password: "",
      role: "tanger",
    })
  }

  const filteredUsers = users?.filter(
    (user) =>
      user?.email?.toLowerCase().includes(searchTerm?.toLowerCase()) ||
      user?.role?.toLowerCase().includes(searchTerm?.toLowerCase()),
  )

  return (
    <div className={`min-h-screen bg-gray-100 p-4 ${dir === "rtl" ? "text-right" : "text-left"}`} dir={dir}>
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
            <h1 className="text-2xl font-bold text-gray-800">{t("dashboard.title")}</h1>
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <button
                onClick={() => {
                  resetForm()
                  setIsAddModalOpen(true)
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md transition-colors"
              >
                {t("dashboard.addUser")}
              </button>
            </div>
          </div>

          <div className="mb-4">
            <input
              type="text"
              placeholder={t("dashboard.search")}
              className="w-full p-2 border border-gray-300 rounded-md"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {isLoading ? (
            <div className="text-center py-4">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
              <p className="mt-2 text-gray-600">{t("dashboard.loading")}</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th
                      className={`px-6 py-3 ${dir === "rtl" ? "text-right" : "text-left"} text-xs font-medium text-gray-500 uppercase tracking-wider`}
                    >
                      {t("dashboard.columns.email")}
                    </th>
                    <th
                      className={`px-6 py-3 ${dir === "rtl" ? "text-right" : "text-left"} text-xs font-medium text-gray-500 uppercase tracking-wider`}
                    >
                      {t("dashboard.columns.role")}
                    </th>
                    <th
                      className={`px-6 py-3 ${dir === "rtl" ? "text-right" : "text-left"} text-xs font-medium text-gray-500 uppercase tracking-wider`}
                    >
                      {t("dashboard.columns.actions")}
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredUsers?.length > 0 ? (
                    filteredUsers?.map((user) => (
                      <tr key={user._id}>
                        <td className="px-6 py-4 whitespace-nowrap">{user.email}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                            ${user.role === "admin"
                                ? "bg-purple-100 text-purple-800"
                                : user.role === "tanger"
                                  ? "bg-blue-100 text-blue-800"
                                  : user.role === "al_hoceima"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-yellow-100 text-yellow-800"
                              }`}
                          >
                            {t(`roles.${user.role}`)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex space-x-3 rtl:space-x-reverse">
                            <button
                              onClick={() => openEditModal(user)}
                              className="text-indigo-600 hover:text-indigo-900"
                            >
                              {t("dashboard.actions.edit")}
                            </button>
                            <button
                              onClick={() => openResetPasswordModal(user)}
                              className="text-orange-600 hover:text-orange-900"
                            >
                              {t("dashboard.actions.resetPassword")}
                            </button>
                            <button onClick={() => openDeleteModal(user)} className="text-red-600 hover:text-red-900">
                              {t("dashboard.actions.delete")}
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={3} className="px-6 py-4 text-center text-gray-500">
                        {t("dashboard.noUsers")}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Add User Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md" dir={dir}>
            <h2 className="text-xl font-bold mb-4">{t("modals.add.title")}</h2>
            <form onSubmit={handleAddUser}>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
                  {t("modals.add.email")}
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">
                  {t("modals.add.password")}
                </label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="role">
                  {t("modals.add.role")}
                </label>
                <select
                  id="role"
                  name="role"
                  value={formData.role}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                >
                  <option value="admin">{t("roles.admin")}</option>
                  <option value="tanger">{t("roles.tanger")}</option>
                  <option value="al_hoceima">{t("roles.al_hoceima")}</option>
                  <option value="nador">{t("roles.nador")}</option>
                </select>
              </div>
              <div className="flex justify-end space-x-2 rtl:space-x-reverse">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-md transition-colors"
                >
                  {t("modals.add.cancel")}
                </button>
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md transition-colors"
                >
                  {t("modals.add.submit")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md" dir={dir}>
            <h2 className="text-xl font-bold mb-4">{t("modals.edit.title")}</h2>
            <form onSubmit={handleUpdateUser}>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="edit-email">
                  {t("modals.edit.email")}
                </label>
                <input
                  type="email"
                  id="edit-email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="edit-role">
                  {t("modals.edit.role")}
                </label>
                <select
                  id="edit-role"
                  name="role"
                  value={formData.role}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                >
                  <option value="admin">{t("roles.admin")}</option>
                  <option value="tanger">{t("roles.tanger")}</option>
                  <option value="al_hoceima">{t("roles.al_hoceima")}</option>
                  <option value="nador">{t("roles.nador")}</option>
                </select>
              </div>
              <div className="flex justify-end space-x-2 rtl:space-x-reverse">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-md transition-colors"
                >
                  {t("modals.edit.cancel")}
                </button>
                <button
                  type="submit"
                  className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md transition-colors"
                >
                  {t("modals.edit.submit")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete User Modal */}
      {isDeleteModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md" dir={dir}>
            <h2 className="text-xl font-bold mb-4">{t("modals.delete.title")}</h2>
            <p className="mb-4">
              {t("modals.delete.message")} <span className="font-semibold">{currentUser?.email}</span>?
            </p>
            <div className="flex justify-end space-x-2 rtl:space-x-reverse">
              <button
                onClick={() => setIsDeleteModalOpen(false)}
                className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-md transition-colors"
              >
                {t("modals.delete.cancel")}
              </button>
              <button
                onClick={handleDeleteUser}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md transition-colors"
              >
                {t("modals.delete.submit")}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reset Password Modal */}
      {isResetPasswordModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md" dir={dir}>
            <h2 className="text-xl font-bold mb-4">{t("modals.resetPassword.title")}</h2>
            <p className="mb-4">
              {t("modals.resetPassword.message")} <span className="font-semibold">{currentUser?.email}</span>
            </p>
            <form onSubmit={handleResetPassword}>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="new-password">
                  {t("modals.resetPassword.newPassword")}
                </label>
                <input
                  type="password"
                  id="new-password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="flex justify-end space-x-2 rtl:space-x-reverse">
                <button
                  type="button"
                  onClick={() => setIsResetPasswordModalOpen(false)}
                  className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-md transition-colors"
                >
                  {t("modals.resetPassword.cancel")}
                </button>
                <button
                  type="submit"
                  className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-md transition-colors"
                >
                  {t("modals.resetPassword.submit")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

export default function DashboardUsers() {
  return <DashboardContent />
}
