"use client"

import { useState, useEffect } from "react"
import { typeApi } from "../../../lib/api"
import { useTranslation } from "react-i18next"

export function TypeForm({ type, categoryId, onClose }) {
  const { t, i18n } = useTranslation()
  const langused = i18n.language
  // Initialize form with existing data or defaults
  const [formData, setFormData] = useState(() => {
    if (type) {
      return {
        ...type,
        name: {
          en: type.name?.en || "",
          fr: type.name?.fr || "",
          es: type.name?.es || "",
          ar: type.name?.ar || "",
        }
      };
    } else {
      return {
        name: { en: "", fr: "", es: "", ar: "" },
        categoryId: categoryId || null,
      };
    }
  });
  const [activeTab, setActiveTab] = useState("en")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState(null)

  const handleChange = (e, lang) => {
    const value = e.target.value;
    setFormData(prev => ({
      ...prev,
      name: {
        ...prev.name,
        [lang]: value,
      },
    }))
    // Clear error state when user makes changes
    if (error) setError(null)
  }

  const validateForm = () => {
    // Ensure at least English name is provided
    if (!formData.name.en?.trim()) {
      setError(t("types.name_required"))
      setActiveTab("en")
      return false
    }
    return true
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!validateForm()) return

    try {
      setIsSubmitting(true)
      setError(null)

      if (type) {
        await typeApi.update(formData)
      } else {
        await typeApi.create(formData)
      }

      onClose(true) // true to refresh data
    } catch (error) {
      console.error("Failed to save type:", error)
      setError(error?.message || t("common.save_failed"))
    } finally {
      setIsSubmitting(false)
    }
  }

  const languages = [
    { code: "en", label: `${t('language.english')}` },
    { code: "fr", label: `${t('language.french')}` },
    { code: "es", label: `${t('language.spanish')}` },
    { code: "ar", label: `${t('language.arabic')}` }
  ]
  useEffect(() => {
    if (!isSubmitting) {
      document.body.classList.add("overflow-hidden");
    } else {
      document.body.classList.remove("overflow-hidden");
    }
    
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, [isSubmitting]);
  return (
    <div className="fixed inset-0 bg-teal-900 bg-opacity-50 flex items-center justify-center z-50 p-3 md:p-6 overflow-hidden">
      <div className="w-full border border-[#ffd699] rounded-lg bg-white shadow-xl max-w-4xl md:max-w-5xl lg:max-w-7xl h-auto max-h-[95vh] flex flex-col">
        <div className="bg-[#ffd699] px-6 py-4 rounded-t-lg">
          <h3 className="text-lg font-semibold text-[#004d4d]">
            {type ? t("types.update_type") : t("types.add_type")}
          </h3>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          <div className="space-y-4 p-6">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md mb-4" role="alert">
                {error}
              </div>
            )}

            <div className="mb-4">
              <div className="flex flex-wrap border-b border-[#ffd699]/30">
                {languages.map(lang => (
                  <button
                    key={lang.code}
                    type="button"
                    className={`px-4 py-2 ${activeTab === lang.code ? "bg-[#004d4d] text-white rounded-t-lg" : "text-[#004d4d]"
                      }`}
                    onClick={() => setActiveTab(lang.code)}
                    aria-selected={activeTab === lang.code}
                    role="tab"
                  >
                    {lang.label}
                  </button>
                ))}
              </div>

              {languages.map(lang => (
                <div
                  key={lang.code}
                  className={`space-y-4 mt-4 ${activeTab === lang.code ? '' : 'hidden'}`}
                  role="tabpanel"
                >
                  <div className="space-y-2">
                    <label htmlFor={`name-${lang.code}`} className="block text-[#004d4d]">
                      {t("types.name")} ({lang.label})
                      {lang.code === "en" && <span className="text-red-500 ml-1">*</span>}
                    </label>
                    <input
                      id={`name-${lang.code}`}
                      value={formData.name?.[lang.code] || ""}
                      onChange={(e) => handleChange(e, lang.code)}
                      required={lang.code === "en"}
                      dir={lang.code === "ar" ? "rtl" : "ltr"}
                      placeholder={t("types.name")}
                      className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699] focus:outline-none"
                      aria-invalid={lang.code === "en" && !formData.name?.en ? "true" : "false"}
                    />
                    {lang.code === "en" && !formData.name?.en && (
                      <p className="text-sm text-red-500 mt-1">{t("types.name_required")}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-between p-6 border-t border-[#ffd699]/30">
            <button
              type="button"
              onClick={() => onClose(false)}
              className="border border-[#004d4d] text-[#004d4d] hover:bg-[#ffd699]/20 px-4 py-2 rounded-md transition-colors"
              disabled={isSubmitting}
            >
              {t("common.cancel")}
            </button>
            <button
              type="submit"
              className="bg-[#004d4d] hover:bg-[#003333] text-white px-6 py-2 rounded-md disabled:opacity-50 transition-colors flex items-center justify-center min-w-[100px]"
              disabled={isSubmitting}
            >
              {isSubmitting ? t("common.saving") : type ? t("types.update_type") : t("types.add_type")}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}