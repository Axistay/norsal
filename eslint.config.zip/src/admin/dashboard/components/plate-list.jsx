"use client"

import { useState, useEffect } from "react"
import { PlateForm } from "./plate-form"
import { plateApi } from "../../../lib/api"
import { useParams } from "react-router-dom"
import ImageModal from "./ImageModal"
import { useTranslation } from "react-i18next"

export function PlateList({ categoryId, onBack }) {
  const { t, i18n } = useTranslation()
  const langused = i18n.language


  const { typeId } = useParams()
  const [plates, setPlates] = useState([])
  const [type, setType] = useState(null)
  const [showForm, setShowForm] = useState(false)
  const [editingPlate, setEditingPlate] = useState(null)
  const [viewMode, setViewMode] = useState("grid")
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [plateToDelete, setPlateToDelete] = useState(null)
  const [showModuleImg, setShowModuleImg] = useState(false)
  const [plateId, setPlateId] = useState(null)

  const handleToogle = () => {
    setShowModuleImg(!showModuleImg)
  }

  const openModule = (id, e) => {
    e.stopPropagation()
    setPlateId(id)
    handleToogle()
  }

  const loadData = async () => {
    try {
      // Get plates for the specific type
      const platesData = await plateApi.getByType(typeId)
      setPlates(platesData)

      // Get type details
      // const typeData = await plateApi.getById(typeId)
      // setType(typeData)
    } catch (error) {
      console.error("Error loading data:", error)
    }
  }

  // Load plates and type data
  useEffect(() => {
    loadData()
  }, [typeId])

  const onSuccess = (data) => {
    if (data) {
      loadData()
    }
  }
  onSuccess()

  const handleEdit = (plate) => {
    setEditingPlate(plate)
    setShowForm(true)
  }

  const handleAddNew = () => {
    setEditingPlate(null)
    setShowForm(true)
  }

  const handleCloseForm = async (refreshData = true) => {
    setShowForm(false)
    setEditingPlate(null)

    if (refreshData) {
      try {
        const refreshedPlates = await plateApi.getByType(typeId)
        setPlates(refreshedPlates)
      } catch (error) {
        console.error("Error refreshing plates:", error)
      }
    }
  }

  const handleDelete = (plate) => {
    setPlateToDelete(plate)
    setDeleteDialogOpen(true)
  }

  const confirmDelete = async () => {
    try {
      await plateApi.delete(plateToDelete._id)
      const updatedPlates = await plateApi.getByType(typeId)
      setPlates(updatedPlates)
      setDeleteDialogOpen(false)
      setPlateToDelete(null)
    } catch (error) {
      console.error("Error deleting plate:", error)
    }
  }

  if (!plates) {
    return <div className="p-4 text-center">Loading...</div>
  }

  return (
    <div className="space-y-6">
      {/* Header with responsive flex layout */}
      <div className="flex items-start justify-between ">
        <div className="flex gap-4">
          <button
            className={`border border-[#004d4d] text-[#004d4d] hover:bg-[#ffd699]/20 p-2 rounded-md ${langused === 'ar' ? 'transform rotate-180 ' : ''}`}

            onClick={onBack}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-4 w-4"
            >
              <path d="m12 19-7-7 7-7"></path>
              <path d="M19 12H5"></path>
            </svg>
            <span className="sr-only">Back</span>
          </button>
          <h2 className="text-xl font-semibold text-[#004d4d]"> {t('plates_count', { count: plates?.length })} </h2></div>
        <div className="flex items-center border border-[#004d4d] rounded-md overflow-hidden">
          <button
            className={`px-3 py-1 text-sm ${viewMode === "grid" ? "bg-[#004d4d] text-white" : "text-[#004d4d] hover:bg-[#ffd699]/20"
              }`}
            onClick={() => setViewMode("grid")}
          >
            {t('common.grid')}
          </button>
          <button
            className={`px-3 py-1 text-sm ${viewMode === "table" ? "bg-[#004d4d] text-white" : "text-[#004d4d] hover:bg-[#ffd699]/20"
              }`}
            onClick={() => setViewMode("table")}
          >
            {t('common.table')}
          </button>
        </div>
        {/* Controls with responsive layout */}

        <button
          onClick={handleAddNew}
          className="bg-[#004d4d] hover:bg-[#003333] text-white px-4 py-2 rounded-md flex items-center"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-4 w-4 mr-2"
          >
            <path d="M5 12h14"></path>
            <path d="M12 5v14"></path>
          </svg>
          <p className=" hidden md:block"> {t('add_plate')}</p>
        </button>
      </div>


      {showForm && <PlateForm plate={editingPlate} typeId={typeId} categoryId={categoryId} onClose={handleCloseForm} />}
      {showModuleImg && <ImageModal isOpen={showModuleImg} onClose={handleToogle} categoryId={plateId} onSuccess={onSuccess} type={'plateS'} />}

      {plates.length === 0 ? (
        <div className="border border-[#ffd699] rounded-lg bg-white p-4 sm:p-8 text-center text-[#004d4d]/70">
          {t('no_plates_found')}
        </div>
      ) : viewMode === "grid" ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
          {plates.map((plate) => (
            <div
              key={plate.id}
              className="overflow-hidden hover:shadow-md transition-shadow border border-[#ffd699] rounded-lg bg-white"
            >
              <div className="relative h-40 sm:h-48">
                <img
                  src={plate.image.url || "/api/placeholder/384/192"}
                  alt={plate.title[langused] || "Plate"}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 right-2 bg-[#ffd699] text-[#004d4d] px-2 py-1 text-sm rounded">
                  {plate.price?.toFixed(2) || "0.00"}
                </div>
              </div>
              <div className="p-3 sm:p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-base sm:text-lg font-semibold text-[#004d4d] break-words pr-2">
                    {plate.title[langused] || "Untitled"}
                  </h3>
                  <div className="flex flex-shrink-0 gap-1">
                    <button
                      className="text-[#ffd699] bg-[#004d4d] hover:bg-[#ffd699]/80 hover:text-[#004d4d] px-2 py-1 text-xs sm:text-sm rounded"
                      onClick={(e) => openModule(plate?._id, e)}
                    >
                      {t('common.img')}
                    </button>
                    <button
                      className="text-[#004d4d] hover:bg-[#ffd699]/20 p-1 rounded"
                      onClick={() => handleEdit(plate)}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-4 w-4"
                      >
                        <path d="M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"></path>
                        <path d="m15 5 4 4"></path>
                      </svg>
                    </button>
                    <button className="text-red-500 hover:bg-red-50 p-1 rounded" onClick={() => handleDelete(plate)}>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-4 w-4"
                      >
                        <path d="M3 6h18"></path>
                        <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path>
                        <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path>
                      </svg>
                    </button>
                  </div>
                </div>
                <p className="text-xs sm:text-sm text-[#004d4d]/70 mb-3 line-clamp-2">{plate.description[langused] || ""}</p>
                <div className="grid grid-cols-4 gap-1 sm:gap-2 text-xs">
                  <div className="text-center">
                    <div className="font-semibold text-[#004d4d]">{plate.nutrition?.calories || 0}</div>
                    <div className="text-[#004d4d]/70">{t('plates.calories')}</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-[#004d4d]">{plate.nutrition?.protein || 0}</div>
                    <div className="text-[#004d4d]/70">{t('plates.protein')}</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-[#004d4d]">{plate.nutrition?.fat || 0}</div>
                    <div className="text-[#004d4d]/70">{t('plates.fat')}</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-[#004d4d]">{plate.nutrition?.carbs || 0}</div>
                    <div className="text-[#004d4d]/70">{t('plates.carbs')}</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="border border-[#ffd699] rounded-lg bg-white overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#004d4d] text-white">
              <tr>
                <th className="w-[80px] text-left p-2 sm:p-3">Image</th>
                <th className="text-left p-2 sm:p-3">Name</th>
                <th className="text-left p-2 sm:p-3 hidden sm:table-cell">Description</th>
                <th className="text-right p-2 sm:p-3">Price</th>
                <th className="text-right p-2 sm:p-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {plates.map((plate) => (
                <tr key={plate.id} className="hover:bg-[#ffd699]/10 border-t border-[#ffd699]/30">
                  <td className="p-2 sm:p-3">
                    <div className="relative h-10 w-10 sm:h-12 sm:w-12 rounded-md overflow-hidden">
                      <img
                        src={plate.image.url || "/api/placeholder/48/48"}
                        alt={plate.title[langused] || "Plate"}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </td>
                  <td className="p-2 sm:p-3 font-medium text-sm sm:text-base text-[#004d4d]">
                    {plate.title[langused] || "Untitled"}
                  </td>
                  <td className="p-2 sm:p-3 max-w-xs truncate text-[#004d4d]/70 hidden sm:table-cell">
                    {plate.description[langused] || ""}
                  </td>
                  <td className="p-2 sm:p-3 text-right text-sm sm:text-base text-[#004d4d]">
                    {plate.price?.toFixed(2) || "0.00"}
                  </td>
                  <td className="p-2 sm:p-3 text-right">
                    <div className="flex flex-wrap justify-end gap-1">
                      <button
                        className="text-[#ffd699] bg-[#004d4d] hover:bg-[#ffd699]/80 hover:text-[#004d4d] px-2 py-1 text-xs sm:text-sm rounded"
                        onClick={(e) => openModule(plate?._id, e)}
                      >
                        {t('common.img')}
                      </button>
                      <button
                        className="text-[#004d4d] hover:bg-[#ffd699]/20 p-1 rounded"
                        onClick={() => handleEdit(plate)}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="24"
                          height="24"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="h-4 w-4"
                        >
                          <path d="M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"></path>
                          <path d="m15 5 4 4"></path>
                        </svg>
                      </button>
                      <button className="text-red-500 hover:bg-red-50 p-1 rounded" onClick={() => handleDelete(plate)}>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="24"
                          height="24"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="h-4 w-4"
                        >
                          <path d="M3 6h18"></path>
                          <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path>
                          <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path>
                        </svg>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Responsive modal dialog */}
      {deleteDialogOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white border border-[#ffd699] rounded-lg p-4 sm:p-6 max-w-md w-full">
            <h3 className="text-lg font-semibold text-[#004d4d]">{t('confirm_deletion_title')}</h3>
            <p className="text-[#004d4d]/70 my-4">
              {t('confirm_deletion_message', { title: plateToDelete?.title[langused] || 'this plate' })}
            </p>
            <div className="flex flex-col sm:flex-row sm:justify-end gap-2">
              <button
                className="border border-[#004d4d] text-[#004d4d] hover:bg-[#ffd699]/20 px-4 py-2 rounded-md w-full sm:w-auto"
                onClick={() => setDeleteDialogOpen(false)}
              >
                {t('common.cancel')}
              </button>
              <button
                className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md w-full sm:w-auto"
                onClick={confirmDelete}
              >
                {t('common.delete')}

              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}