"use client"

import { useState, useEffect, useRef } from "react"

const ColorPicker = ({ value, onChange }) => {
  const [showPicker, setShowPicker] = useState(false)
  const [currentColor, setCurrentColor] = useState(value || "#004d4d")
  const pickerRef = useRef(null)
  
  // Predefined color options
  const colorOptions = [
    "#004d4d", "#ffd699", "#ffffff", "#3498db", "#e74c3c", 
    "#2ecc71", "#f39c12", "#9b59b6", "#1abc9c", "#34495e"
  ]

  useEffect(() => {
    setCurrentColor(value)
  }, [value])

  useEffect(() => {
    // Handle clicks outside the color picker to close it
    const handleClickOutside = (event) => {
      if (pickerRef.current && !pickerRef.current.contains(event.target)) {
        setShowPicker(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  const handleColorChange = (e) => {
    const newColor = e.target.value
    setCurrentColor(newColor)
    onChange(newColor)
  }

  const selectColor = (color) => {
    setCurrentColor(color)
    onChange(color)
    setShowPicker(false)
  }

  return (
    <div className="relative" ref={pickerRef}>
      <div className="flex items-center space-x-2">
        <div 
          className="w-10 h-10 border border-gray-300 rounded-md cursor-pointer"
          style={{ backgroundColor: currentColor }}
          onClick={() => setShowPicker(!showPicker)}
        />
        <input
          type="text"
          value={currentColor}
          onChange={handleColorChange}
          className="border border-gray-300 rounded-md p-2 w-28 text-sm"
          placeholder="#000000"
        />
        <input
          type="color"
          value={currentColor}
          onChange={handleColorChange}
          className="w-10 h-10 cursor-pointer"
        />
      </div>
      
      {showPicker && (
        <div className="absolute mt-2 p-3 bg-white border border-gray-300 rounded-md shadow-lg z-10">
          <div className="grid grid-cols-5 gap-2">
            {colorOptions.map((color) => (
              <button
                key={color}
                type="button"
                className={`w-8 h-8 rounded-md ${
                  color === currentColor 
                    ? "ring-2 ring-offset-2 ring-blue-500" 
                    : color === "#ffffff" ? "border border-gray-300" : ""
                }`}
                style={{ backgroundColor: color }}
                onClick={() => selectColor(color)}
              />
            ))}
          </div>
          <div className="mt-2">
            <input
              type="color"
              value={currentColor}
              onChange={handleColorChange}
              className="w-full h-8 cursor-pointer"
            />
          </div>
        </div>
      )}
    </div>
  )
}

export default ColorPicker