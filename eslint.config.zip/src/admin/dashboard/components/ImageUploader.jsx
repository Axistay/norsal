import React, { useState, useEffect } from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
import { useTranslation } from 'react-i18next';
import { axiosInstance } from '../../../lib/api';

// Base API URL - should be in environment variable in production
const API_BASE_URL = 'http://localhost:3009/api';

const ImageUploader = ({ 
  categoryId, 
  onSuccess, 
  onClose, 
  maxSizeMB = 5,
  currentImageUrl = null,
  type
}) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState(null);
  const { t } = useTranslation();

  // Clean up object URL when component unmounts
  useEffect(() => {
    return () => {
      if (preview && preview.url) {
        URL.revokeObjectURL(preview.url);
      }
    };
  }, [preview]);

  // Handle file selection
  const handleFileSelect = (event) => {
    setError(null);
    const file = event.target.files[0];
    
    if (!file) return;
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
      setError(t('imageUploader.selectImageFile'));
      return;
    }
    
    // Validate file size
    if (file.size > maxSizeMB * 1024 * 1024) {
      setError(t('imageUploader.fileSizeExceeded', { maxSize: maxSizeMB }));
      return;
    }
    
    // Clear previous preview if exists
    if (preview && preview.url) {
      URL.revokeObjectURL(preview.url);
    }
    
    // Set selected file and generate preview
    setSelectedFile(file);
    setPreview({
      url: URL.createObjectURL(file),
      name: file.name,
      size: file.size
    });
  };

  // Remove selected file
  const handleRemoveFile = () => {
    if (preview && preview.url) {
      URL.revokeObjectURL(preview.url);
    }
    setSelectedFile(null);
    setPreview(null);
  };

  // Upload file to server
  const handleUpload = async () => {
    if (!selectedFile) {
      setError(t('imageUploader.selectImageToUpload'));
      return;
    }
    
    if (!categoryId) {
      setError(t('imageUploader.categoryIdRequired'));
      return;
    }
    
    setIsUploading(true);
    setError(null);
    setUploadProgress(0);
    
    try {
      const formData = new FormData();
      formData.append('image', selectedFile);
      
      // Send upload request with progress tracking
      const response = await axiosInstance.put(
        `${API_BASE_URL}/${type}/${categoryId}/image`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data'
          },
          onUploadProgress: (progressEvent) => {
            const percentCompleted = Math.round(
              (progressEvent.loaded * 100) / progressEvent.total
            );
            setUploadProgress(percentCompleted);
          }
        }
      );
      
      // Handle successful upload
      if (response.data.success) {
        // Clear selected file and preview
        if (preview && preview.url) {
          URL.revokeObjectURL(preview.url);
        }
        setSelectedFile(null);
        setPreview(null);
        
        // Call success callback with response data
        if (typeof onSuccess === 'function') {
          onSuccess(response.data);
        }
        
        // Close modal if provided
        if (typeof onClose === 'function') {
          onClose();
        }
      } else {
        setError(response.data.message || t('imageUploader.uploadFailed'));
      }
    } catch (err) {
      console.error('Upload error:', err);
      setError(
        err.response?.data?.message || 
        err.message || 
        t('imageUploader.uploadError')
      );
    } finally {
      setIsUploading(false);
    }
  };

  // Format file size for display
  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-2xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">{t('imageUploader.uploadImage')}</h2>
        {onClose && (
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 focus:outline-none"
            aria-label="Close"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>
      
      {/* Current image display */}
      {currentImageUrl && !preview && (
        <div className="mb-6">
          <h3 className="text-sm font-medium text-gray-700 mb-3">Current Image</h3>
          <div className="relative border rounded-lg overflow-hidden">
            <img
              src={currentImageUrl}
              alt="Current"
              className="w-full h-48 object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-60 text-white text-xs p-2">
              <p>Uploading a new image will replace this one</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Error message */}
      {error && (
        <div className="mb-4 p-3 bg-red-100 border border-red-300 text-red-700 rounded">
          {error}
        </div>
      )}
      
      {/* Upload area */}
      <div 
        className={`border-2 border-dashed rounded-lg p-8 text-center mb-6
          ${isUploading ? 'border-gray-300 bg-gray-50' : 'border-blue-300 hover:border-blue-500 bg-blue-50'}`}
      >
        <input
          type="file"
          id="image-upload"
          accept="image/*"
          onChange={handleFileSelect}
          disabled={isUploading}
          className="hidden"
        />
        
        {!isUploading ? (
          <label 
            htmlFor="image-upload"
            className="flex flex-col items-center cursor-pointer"
          >
            <svg className="w-12 h-12 text-blue-500 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
            </svg>
            <span className="text-gray-700 font-medium">{t('imageUploader.clickToSelectImage')}</span>
            <span className="text-gray-500 text-sm mt-1">
              {t('imageUploader.maxFileSize', { maxSize: maxSizeMB })}
            </span>
          </label>
        ) : (
          <div className="flex flex-col items-center">
            <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
              <div 
                className="bg-blue-600 h-2.5 rounded-full" 
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
            <span className="text-gray-700">
              {t('imageUploader.uploading', { progress: uploadProgress })}
            </span>
          </div>
        )}
      </div>
      
      {/* Preview area */}
      {preview && (
        <div className="mb-6">
          <h3 className="text-sm font-medium text-gray-700 mb-3">
            {t('imageUploader.selectedImage')}
          </h3>
          
          <div className="relative group border rounded-lg overflow-hidden">
            <img
              src={preview.url}
              alt="Preview"
              className="w-full h-48 object-cover"
            />
            
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-opacity">
              <button
                onClick={handleRemoveFile}
                disabled={isUploading}
                className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                aria-label={t('imageUploader.removeImage')}
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-60 text-white text-xs p-1 truncate">
              {preview.name} ({formatFileSize(preview.size)})
            </div>
          </div>
        </div>
      )}
      
      {/* Action buttons */}
      <div className="flex justify-end space-x-3">
        {onClose && (
          <button
            onClick={onClose}
            disabled={isUploading}
            className="px-4 mx-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            {t('common.cancel')}
          </button>
        )}
        
        <button
          onClick={handleUpload}
          disabled={isUploading || !selectedFile}
          className={`px-4 py-2 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500
            ${
              isUploading || !selectedFile
                ? 'bg-blue-300 cursor-not-allowed'
                : 'bg-blue-600 hover:bg-blue-700'
            }`}
        >
          {isUploading ? t('imageUploader.selectedImage') : t('imageUploader.uploadImage')}
        </button>
      </div>
    </div>
  );
};

ImageUploader.propTypes = {
  categoryId: PropTypes.string.isRequired,
  onSuccess: PropTypes.func,
  onClose: PropTypes.func,
  maxSizeMB: PropTypes.number,
  currentImageUrl: PropTypes.string
};

export default ImageUploader;