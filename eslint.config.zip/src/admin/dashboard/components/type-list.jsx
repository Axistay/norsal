"use client"

import { useState, useEffect } from "react"
import { useParams } from "react-router-dom"
import { TypeForm } from "./type-form"
import { typeApi } from "../../../lib/api"
import { useTranslation } from "react-i18next"

export function TypeList({ onTypeSelect, onBack }) {
  const { t, i18n } = useTranslation()
  const currentLanguage = i18n.language  // Default to 'en' if language isn't set

  const { id } = useParams()
  const [types, setTypes] = useState([])
  const [category, setCategory] = useState(null)
  const [showForm, setShowForm] = useState(false)
  const [editingType, setEditingType] = useState(null)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [typeToDelete, setTypeToDelete] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  // Load types and category data
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true)
      setError(null)
      try {
        // Get types for this category
        const typesData = await typeApi.getByCategory(id)
        setTypes(typesData)
        
        // Get category details - assuming there's a getCategory method
        const categoryData = await typeApi.getByCategory(id)
        setCategory(categoryData)
      } catch (err) {
        console.error("Error fetching data:", err)
        setError("Failed to load data. Please try again.")
      } finally {
        setIsLoading(false)
      }
    }
    
    fetchData()
  }, [id])

  const handleEdit = (type, e) => {
    e.stopPropagation()
    setEditingType(type)
    setShowForm(true)
  }

  const handleAddNew = () => {
    setEditingType(null)
    setShowForm(true)
  }

  const handleCloseForm = async (refreshData = false) => {
    setShowForm(false)
    setEditingType(null)
    
    if (refreshData) {
      try {
        const updatedTypes = await typeApi.getByCategory(id)
        setTypes(updatedTypes)
      } catch (err) {
        console.error("Error refreshing types:", err)
        setError("Failed to refresh data. Please try again.")
      }
    }
  }

  const handleDelete = (type, e) => {
    e.stopPropagation()
    setTypeToDelete(type)
    setDeleteDialogOpen(true)
  }

  const confirmDelete = async () => {
    try {
      // Ensure we're using the correct ID property
      await typeApi.delete(typeToDelete._id || typeToDelete.id)
      
      // Refresh types after deletion
      const updatedTypes = await typeApi.getByCategory(id)
      setTypes(updatedTypes)
      
      setDeleteDialogOpen(false)
      setTypeToDelete(null)
    } catch (err) {
      console.error("Error deleting type:", err)
      setError("Failed to delete type. Please try again.")
      setDeleteDialogOpen(false)
    }
  }

  if (isLoading) {
    return <div className="flex justify-center p-8">Loading...</div>
  }

  if (error) {
    return (
      <div className="p-4 border border-red-300 bg-red-50 text-red-700 rounded-md">
        {error}
        <button 
          className="ml-4 underline" 
          onClick={() => window.location.reload()}
        >
          Retry
        </button>
      </div>
    )
  }

  // Helper function to safely get localized name
  const getLocalizedName = (item) => {
    if (!item || !item.name) return "Unnamed";
    return item.name[currentLanguage] || item.name.en || Object.values(item.name)[0] || "Unnamed";
  }

  return (
    <div className="space-y-6"  >
      <div className="flex items-start justify-between  gap-4">
        <button
          className={`border border-[#004d4d] text-[#004d4d] hover:bg-[#ffd699]/20 p-2 rounded-md ${currentLanguage === 'ar' ? 'transform rotate-180 ' : ''}`}
          onClick={onBack}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-4 w-4"
          >
            <path d="m12 19-7-7 7-7"></path>
            <path d="M19 12H5"></path>
          </svg>
        </button>
        <h2 className="text-xl font-semibold text-[#004d4d]">
        {t('types.types_count', {count : types?.length || 0})} 
        </h2>
        <button
          className=" bg-[#004d4d] hover:bg-[#003333] text-white px-4 py-2 rounded-md flex items-center"
          onClick={handleAddNew}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-4 w-4 mr-2"
          >
            <path d="M5 12h14"></path>
            <path d="M12 5v14"></path>
          </svg>
          <p className=" hidden md:block"> {t('types.add_type')} </p>
        </button>
      </div>

      {showForm && (
        <TypeForm 
          type={editingType} 
          categoryId={id} 
          onClose={handleCloseForm} 
        />
      )}

      {types.length === 0 ? (
        <div className="text-center p-8 text-gray-500">
          {t('types.no_types_found')}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {types.map((type) => (
            <div
              key={type._id || type.id}
              className="hover:shadow-md transition-shadow cursor-pointer border border-[#ffd699] rounded-lg bg-white"
              onClick={() => onTypeSelect(type._id || type.id, id)}
            >
              <div className="p-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-[#004d4d] truncate">
                    {getLocalizedName(type)}
                  </h3>
                  <div className="flex gap-1">
                    <button
                      className="text-[#004d4d] hover:bg-[#ffd699]/20 p-1 rounded"
                      onClick={(e) => handleEdit(type, e)}
                      aria-label={t('common.edit')}
                    >
                      {t('common.edit')}
                    </button>
                    <button 
                      className="text-red-500 hover:bg-red-50 p-1 rounded" 
                      onClick={(e) => handleDelete(type, e)}
                      aria-label={t('common.delete')}
                    >
                      {t('common.delete')}
                    </button>
                  </div>
                </div>
                <div className="h-1 w-16 mt-2 bg-[#004d4d]"></div>
              </div>
            </div>
          ))}
        </div>
      )}

      {deleteDialogOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white border border-[#ffd699] rounded-lg p-6 max-w-md w-full">
            <h3 className="text-lg font-semibold text-[#004d4d]">{t('types.confirm_deletion')}</h3>
            <p className="text-[#004d4d]/70 my-4">
              {t('types.delete_confirmation', { typeName: getLocalizedName(typeToDelete) })}
            </p>
            <div className="flex justify-end gap-2">
              <button
                className="border border-[#004d4d] text-[#004d4d] hover:bg-[#ffd699]/20 px-4 py-2 rounded-md"
                onClick={() => setDeleteDialogOpen(false)}
              >
                {t('common.cancel')}
              </button>
              <button 
                className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md" 
                onClick={confirmDelete}
              >
                {t('common.delete')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}