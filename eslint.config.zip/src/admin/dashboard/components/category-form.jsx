"use client"

import { useEffect, useState } from "react"
import { categoryApi } from "../../../lib/api"
import { useParams } from "react-router-dom"
import ImageModal from "./ImageModal"
import ColorPicker from "./ColorPicker"
import { useTranslation } from "react-i18next"

export function CategoryForm({ category, onClose }) {
  const { t, i18n } = useTranslation()
  const langused = i18n.language
  const { cityId } = useParams()
  const [formData, setFormData] = useState(
    category || {
      name: { en: "", fr: "", es: "", ar: "" },
      description: { en: "", fr: "", es: "", ar: "" },
      color: "#004d4d",
      image: "",
      city: cityId
    },
  )
  const [activeTab, setActiveTab] = useState("en")
  const [isLoading, setIsLoading] = useState(false)
  const [errorMessage, setErrorMessage] = useState("")

  const handleChange = (field, value, lang) => {
    if (lang) {
      setFormData({
        ...formData,
        [field]: {
          ...formData[field],
          [lang]: value,
        },
      })
    } else {
      setFormData({
        ...formData,
        [field]: value,
      })
    }
  }

 

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setErrorMessage("");
      setIsLoading(true);
      
      const requiredFields = ["en"];
      
      for (const field of requiredFields) {
        if (!formData.name[field] || !formData.description[field]) {
          setErrorMessage(`${field.toUpperCase()} ${t("common.required_fields")}`);
          setIsLoading(false);
          setActiveTab(field);
          return;
        }
      }
      
      
      if (category) {
        await updateCategory(category.id || category._id);
      } else {
        await addCategory();
      }
      onClose(true);
    } catch (error) {
      console.error('Error saving category:', error);
      setErrorMessage(error.response?.data?.message || t("common.save_failed"));
    } finally {
      setIsLoading(false);
    }
  };
  
  const addCategory = async () => {
    const categoryData = {
      name: formData.name,
      description: formData.description,
      color: formData.color,
      city: formData.city,
      image: formData.image
    };
  
    const response = await categoryApi.create(categoryData);
  };
  
  const updateCategory = async (categoryId) => {
    const categoryData = {
      name: formData.name,
      description: formData.description,
      color: formData.color,
      city: formData.city,
      image: formData.image
    };
  
    const response = await categoryApi.update(categoryId, categoryData);
  };
  useEffect(() => {
    if (!isLoading) {
      document.body.classList.add("overflow-hidden");
    } else {
      document.body.classList.remove("overflow-hidden");
    }
    
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, [isLoading]);
  return (
    <div className="fixed inset-0 bg-teal-900 bg-opacity-50 flex items-center justify-center z-50 p-3 md:p-6 overflow-hidden">
      <div className="w-full border border-[#ffd699] rounded-lg bg-white shadow-xl max-w-4xl md:max-w-5xl lg:max-w-7xl h-auto max-h-[95vh] flex flex-col">

      <div className="bg-[#ffd699] px-6 py-4 rounded-t-lg">
        <h3 className="text-lg font-semibold text-[#004d4d]">{category ? t("common.edit_category") : t("common.add_new_category")}</h3>
      </div>
      {errorMessage && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 mx-6 mt-4 rounded">
          <span className="block sm:inline">{errorMessage}</span>
        </div>
      )}
      <form onSubmit={handleSubmit}>
        <div className="space-y-4 p-6">
          <div className="mb-4">
            <div className="flex border-b border-[#ffd699]/30">
              <button
                type="button"
                className={`px-4 py-2 ${
                  activeTab === "en" ? "bg-[#004d4d] text-white rounded-t-lg" : "text-[#004d4d]"
                }`}
                onClick={() => setActiveTab("en")}
              >
                {t("language.english")}
              </button>
              <button
                type="button"
                className={`px-4 py-2 ${
                  activeTab === "fr" ? "bg-[#004d4d] text-white rounded-t-lg" : "text-[#004d4d]"
                }`}
                onClick={() => setActiveTab("fr")}
              >
                {t("language.french")}
              </button>
              <button
                type="button"
                className={`px-4 py-2 ${
                  activeTab === "es" ? "bg-[#004d4d] text-white rounded-t-lg" : "text-[#004d4d]"
                }`}
                onClick={() => setActiveTab("es")}
              >
                {t("language.spanish")}
              </button>
              <button
                type="button"
                className={`px-4 py-2 ${
                  activeTab === "ar" ? "bg-[#004d4d] text-white rounded-t-lg" : "text-[#004d4d]"
                }`}
                onClick={() => setActiveTab("ar")}
              >
                {t("language.arabic")}
              </button>
            </div>

            {activeTab === "en" && (
              <div className="space-y-4 mt-4">
                <div className="space-y-2">
                  <label htmlFor="name-en" className="block text-[#004d4d]">
                    {t("common.name")} {t("language.english")} <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="name-en"
                    value={formData.name?.en || ""}
                    onChange={(e) => handleChange("name", e.target.value, "en")}
                    required
                    className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699]"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="description-en" className="block text-[#004d4d]">
                    {t("common.description")} {t("language.english")} <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="description-en"
                    value={formData.description?.en || ""}
                    onChange={(e) => handleChange("description", e.target.value, "en")}
                    required
                    className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699]"
                    rows={3}
                  />
                </div>
              </div>
            )}

            {activeTab === "fr" && (
              <div className="space-y-4 mt-4">
                <div className="space-y-2">
                  <label htmlFor="name-fr" className="block text-[#004d4d]">
                    {t("common.name")} {t("language.french")}
                  </label>
                  <input
                    id="name-fr"
                    value={formData.name?.fr || ""}
                    onChange={(e) => handleChange("name", e.target.value, "fr")}
                    className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699]"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="description-fr" className="block text-[#004d4d]">
                    {t("common.description")} {t("language.french")}
                  </label>
                  <textarea
                    id="description-fr"
                    value={formData.description?.fr || ""}
                    onChange={(e) => handleChange("description", e.target.value, "fr")}
                    className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699]"
                    rows={3}
                  />
                </div>
              </div>
            )}

            {activeTab === "es" && (
              <div className="space-y-4 mt-4">
                <div className="space-y-2">
                  <label htmlFor="name-es" className="block text-[#004d4d]">
                    {t("common.name")} {t("language.spanish")}
                  </label>
                  <input
                    id="name-es"
                    value={formData.name?.es || ""}
                    onChange={(e) => handleChange("name", e.target.value, "es")}
                    className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699]"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="description-es" className="block text-[#004d4d]">
                    {t("common.description")} {t("language.spanish")}
                  </label>
                  <textarea
                    id="description-es"
                    value={formData.description?.es || ""}
                    onChange={(e) => handleChange("description", e.target.value, "es")}
                    className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699]"
                    rows={3}
                  />
                </div>
              </div>
            )}

            {activeTab === "ar" && (
              <div className="space-y-4 mt-4">
                <div className="space-y-2">
                  <label htmlFor="name-ar" className="block text-[#004d4d]">
                    {t("common.name")} {t("language.arabic")}
                  </label>
                  <input
                    id="name-ar"
                    value={formData.name?.ar || ""}
                    onChange={(e) => handleChange("name", e.target.value, "ar")}
                    dir="rtl"
                    className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699]"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="description-ar" className="block text-[#004d4d]">
                    {t("common.description")} {t("language.arabic")}
                  </label>
                  <textarea
                    id="description-ar"
                    value={formData.description?.ar || ""}
                    onChange={(e) => handleChange("description", e.target.value, "ar")}
                    dir="rtl"
                    className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699]"
                    rows={3}
                  />
                </div>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label className="block text-[#004d4d]">{t("categories.category_color")}</label>
            <ColorPicker 
              value={formData.color} 
              onChange={(color) => handleChange("color", color)} 
            />
            <div className="mt-2 text-sm text-gray-500">
              {t("categories.category_color_description")}
            </div>
          </div>

        </div>
        <div className="flex justify-between p-6 border-t border-[#ffd699]/30">
          <button
            type="button"
            onClick={() => onClose(false)}
            className="border border-[#004d4d] text-[#004d4d] hover:bg-[#ffd699]/20 px-4 py-2 rounded-md"
            disabled={isLoading}
          >
            {t("common.cancel")}
          </button>
          <button 
            type="submit" 
            className={`bg-[#004d4d] hover:bg-[#003333] text-white px-4 py-2 rounded-md ${
              isLoading ? "opacity-70 cursor-not-allowed" : ""
            }`}
            disabled={isLoading}
          >
            {isLoading ? 
              t("common.saving") : 
              (category ? t("common.update_category") : t("common.add_category"))
            }
          </button>
        </div>
      </form>
    </div>
    </div>
  )
} 