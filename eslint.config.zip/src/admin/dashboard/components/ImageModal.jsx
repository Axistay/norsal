// React Component: ImageModal.jsx
import React from 'react';
import PropTypes from 'prop-types';
import ImageUploader from './ImageUploader';
import { useParams } from 'react-router-dom';

const ImageModal = ({ isOpen, onClose, onSuccess, categoryId , type}) => {
  // If modal is not open, don't render anything
  if (!isOpen) return null;

  // Prevent clicks inside the modal from closing it
  const handleModalClick = (e) => {
    e.stopPropagation();
  };

  return (
    <div 
      className="fixed inset-0 z-50 overflow-y-auto bg-black bg-opacity-50 flex items-center justify-center p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div 
        className="w-full max-w-2xl animate-appear"
        onClick={handleModalClick}
      >
        <ImageUploader
          categoryId={categoryId}
          onSuccess={onSuccess}
          onClose={onClose}
          type={type}
        />
      </div>
    </div>
  );
};

ImageModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  categoryId: PropTypes.string.isRequired,
  onSuccess: PropTypes.func
};

export default ImageModal;