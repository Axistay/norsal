"use client"

export function CityCounts({ categoriesCount }) {
  return (
    <div className="bg-white rounded-lg shadow-md border border-[#ffd699] overflow-hidden">
      <div className="p-6">
       
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {categoriesCount && categoriesCount > 0 ? (
            <p>Category {categoriesCount}</p>
        ) : (
          <p>No categories available</p>
        )}

        </div>
      </div>
    </div>
  )
}