"use client"

import { useState, useEffect } from "react"
import { getAllImages, addCustomImage } from "../../lib/data-utils"

export function ImageSelector({ selectedImage, onSelectImage }) {
  const [images, setImages] = useState([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [customImageUrl, setCustomImageUrl] = useState("")
  const [customImageTitle, setCustomImageTitle] = useState("")
  const [activeTab, setActiveTab] = useState("gallery")
  const [error, setError] = useState("")
  const [customImageFile, setCustomImageFile] = useState(null)

  useEffect(() => {
    setImages(getAllImages())
  }, [])

  const handleSelectImage = (image) => {
    onSelectImage(image.url)
    setIsDialogOpen(false)
  }

  const handleAddCustomImage = () => {
    if (!customImageFile) {
      setError("Please select an image file")
      return
    }

    try {
      const newImage = addCustomImage({
        url: URL.createObjectURL(customImageFile),
        title: customImageTitle || "Custom Image",
      })

      setImages([...images, newImage])
      setCustomImageFile(null)
      setCustomImageTitle("")
      setError("")
      setActiveTab("gallery")
    } catch (error) {
      setError("Failed to add image. Please try again.")
    }
  }

  return (
    <div>
      <div className="flex items-center gap-2">
        <div className="relative h-20 w-20 border border-[#004d4d] rounded-md overflow-hidden">
          <img
            src={selectedImage || "/placeholder.svg?height=80&width=80"}
            alt="Selected image"
            className="object-cover w-full h-full"
          />
        </div>
        <button
          type="button"
          onClick={() => setIsDialogOpen(true)}
          className="px-4 py-2 bg-[#004d4d] hover:bg-[#003333] text-white rounded-md transition-colors"
        >
          Select Image
        </button>
      </div>

      {isDialogOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-hidden border border-[#ffd699]">
            <div className="p-4 border-b border-[#ffd699]">
              <h2 className="text-xl font-semibold text-[#004d4d]">Select an Image</h2>
              <button
                onClick={() => setIsDialogOpen(false)}
                className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-6 w-6"
                >
                  <path d="M18 6 6 18"></path>
                  <path d="m6 6 12 12"></path>
                </svg>
              </button>
            </div>

            <div className="p-4">
              <div className="flex border-b border-[#ffd699]/30 mb-4">
                <button
                  className={`px-4 py-2 ${
                    activeTab === "gallery" ? "bg-[#004d4d] text-white" : "text-[#004d4d] hover:bg-[#ffd699]/20"
                  } rounded-t-md transition-colors`}
                  onClick={() => setActiveTab("gallery")}
                >
                  Image Gallery
                </button>
                <button
                  className={`px-4 py-2 ${
                    activeTab === "custom" ? "bg-[#004d4d] text-white" : "text-[#004d4d] hover:bg-[#ffd699]/20"
                  } rounded-t-md transition-colors`}
                  onClick={() => setActiveTab("custom")}
                >
                  Add Custom Image
                </button>
              </div>

              {activeTab === "gallery" ? (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-h-[60vh] overflow-y-auto p-2">
                  {images.map((image) => (
                    <div
                      key={image.id}
                      className={`cursor-pointer hover:shadow-md transition-shadow border border-[#ffd699] rounded-md overflow-hidden ${
                        selectedImage === image.url ? "ring-2 ring-[#004d4d]" : ""
                      }`}
                      onClick={() => handleSelectImage(image)}
                    >
                      <div className="relative h-32 w-full">
                        <img src={image.url || "/placeholder.svg"} alt={image.title} className="object-cover w-full h-full" />
                      </div>
                      <div className="p-2">
                        <p className="text-xs text-[#004d4d] truncate">{image.title}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label htmlFor="image-file" className="block text-[#004d4d] font-medium">
                      Select Image File
                    </label>
                    <input
                      id="image-file"
                      type="file"
                      accept="image/*"
                      onChange={(e) => setCustomImageFile(e.target.files[0])}
                      className="w-full px-3 py-2 border border-[#004d4d] rounded-md focus:outline-none focus:ring-2 focus:ring-[#ffd699]"
                    />
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="image-title" className="block text-[#004d4d] font-medium">
                      Image Title (Optional)
                    </label>
                    <input
                      id="image-title"
                      value={customImageTitle}
                      onChange={(e) => setCustomImageTitle(e.target.value)}
                      placeholder="My Custom Image"
                      className="w-full px-3 py-2 border border-[#004d4d] rounded-md focus:outline-none focus:ring-2 focus:ring-[#ffd699]"
                    />
                  </div>

                  {error && <p className="text-red-500 text-sm">{error}</p>}

                  {customImageFile && (
                    <div className="mt-4">
                      <p className="text-sm text-[#004d4d] mb-2">Preview:</p>
                      <div className="relative h-40 w-full border border-[#004d4d] rounded-md overflow-hidden">
                        <img
                          src={URL.createObjectURL(customImageFile)}
                          alt="Preview"
                          className="object-cover w-full h-full"
                          onError={() => setError("Invalid image file. Please try another.")}
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="p-4 border-t border-[#ffd699] flex justify-between">
              <button
                type="button"
                onClick={() => setIsDialogOpen(false)}
                className="px-4 py-2 border border-[#004d4d] text-[#004d4d] hover:bg-[#ffd699]/20 rounded-md transition-colors"
              >
                Cancel
              </button>
              {activeTab === "custom" && (
                <button
                  type="button"
                  onClick={handleAddCustomImage}
                  className="px-4 py-2 bg-[#004d4d] hover:bg-[#003333] text-white rounded-md transition-colors"
                >
                  Add Image
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
