"use client"

import { useState, useEffect, useRef } from "react"
import { Link, useLocation } from "react-router-dom"
import Language from "../../../pages/Language"
import { Languages, X, Menu, User } from "lucide-react"
import { useTranslation } from "react-i18next"
import { useAuth } from "../../../context/AuthContext"
export function DashboardHeader() {
  const {user, logout} = useAuth()
  const { t, i18n } = useTranslation()
  const currentLanguage = i18n.language
  
  const location = useLocation()
  const pathname = location.pathname
  // State management
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false)
  const [showLanguageOptions, setShowLanguageOptions] = useState(false)
  const [windowWidth, setWindowWidth] = useState(
    typeof window !== "undefined" ? window.innerWidth : 0
  )
  
  // Refs for click outside detection
  const userMenuRef = useRef(null)
  const languageMenuRef = useRef(null)

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth)
      // Close mobile menu when resizing to desktop view
      if (window.innerWidth > 768) {
        setIsMobileMenuOpen(false)
      }
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  // Handle clicks outside menus
  useEffect(() => {
    const handleClickOutside = (event) => {
      // Close user menu if clicked outside
      if (isUserMenuOpen && 
          userMenuRef.current && 
          !userMenuRef.current.contains(event.target)) {
        setIsUserMenuOpen(false)
      }
      
      // Close language menu if clicked outside (except modal which has its own close button)
      if (!showLanguageOptions) {
        if (languageMenuRef.current && 
            !languageMenuRef.current.contains(event.target)) {
          setShowLanguageOptions(false)
        }
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [isUserMenuOpen, showLanguageOptions])

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen)
    // Close other menus when opening mobile menu
    if (!isMobileMenuOpen) {
      setIsUserMenuOpen(false)
      setShowLanguageOptions(false)
    }
  }

  const toggleLanguageOptions = () => {
    setShowLanguageOptions(!showLanguageOptions)
    // Close other menus
    setIsUserMenuOpen(false)
  }

  const closeLanguageOptions = () => {
    setShowLanguageOptions(false)
  }

  const toggleUserMenu = () => {
    setIsUserMenuOpen(!isUserMenuOpen)
    // Close other menus
    setShowLanguageOptions(false)
  }

  const handleLogout = () => {
    logout()
    window.location.href = "/admin/login"
  }

  return (
    <header className="bg-[#114e51] text-white sticky top-0 z-30">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Left side - Logo and Mobile Menu Button */}
          <div className="flex items-center space-x-4">
            {/* Mobile menu button - only show on small screens */}
            {user?.role === 'admin' && (
            <button
              className="lg:hidden text-white hover:bg-[#003333] p-2 rounded-full"
              onClick={toggleMobileMenu}
              aria-expanded={isMobileMenuOpen}
              aria-controls="mobile-menu"
            >
              <Menu size={24} />
              <span className="sr-only">Menu</span>
            </button>
            )}
            
            {/* Logo */}
            <Link to="/" className="flex items-center">
              <img 
                src="/image0.png" 
                alt="Logo" 
                className="h-8 w-auto sm:h-10"
              />
            </Link>
          </div>
 
          {/* Desktop Navigation - Hide on small screens */}
          {user?.role === 'admin' && (
          <nav className="hidden lg:flex items-center space-x-6">
            <Link 
              to="/admin/dashboard/nador" 
              className={`text-white hover:text-[#ffd699]  px-4 py-2 transition-colors ${!pathname.includes('users') ? 'text-[#ffd699] bg-teal-500 rounded-md' : ''}`}
            >
              {t('dashboard.dashboard')}
            </Link>
            
            <Link 
              to="/admin/dashboard/users" 
              className={`text-white hover:text-[#ffd699]  px-4 py-2 transition-colors ${pathname.includes('users') ? 'text-[#ffd699] bg-teal-500 rounded-md' : ''}`}
            >
              {t('dashboard.users')}
            </Link>
          </nav>
          )}

          {/* Right side - Language & User buttons */}
          <div className="flex items-center gap-2">
            <div ref={languageMenuRef}>
              <button
                onClick={toggleLanguageOptions}
                className="text-white hover:bg-[#003333] p-2 rounded-full flex items-center justify-center"
                aria-expanded={showLanguageOptions}
              >
                <Languages size={20} />
              </button>
            </div>


            <div className="relative" ref={userMenuRef}>
              <button
                className="rounded-full text-white hover:bg-[#003333] p-2 flex items-center justify-center"
                onClick={toggleUserMenu}
                aria-expanded={isUserMenuOpen}
                aria-haspopup="true"
              >
                <User size={20} />
              </button>

              {isUserMenuOpen && (
                <div 
                  className={`absolute ${
                    currentLanguage === 'ar' 
                      ? 'left-0 md:left-auto md:right-0' 
                      : 'right-0'
                  } mt-2 w-48 bg-[#e6f7f7] rounded-md shadow-lg border border-[#ffd699] overflow-hidden z-40`}
                >
                  <div className="px-4 py-2 text-[#004d4d] font-medium border-b border-[#ffd699]/50 bg-[#c2eaea]">
                    {t('dashboard.adminAccount')}
                  </div>
                  <button className="w-full px-4 py-2 text-left text-[#004d4d] hover:bg-[#ffd699]/20">
                    {t('dashboard.profile')}
                  </button>
                  
                  <div className="border-t border-[#ffd699]/50"></div>
                  <button
                    className="w-full px-4 py-2 text-left text-[#004d4d] hover:bg-[#ffd699]/20"
                    onClick={handleLogout}
                  >
                    {t('dashboard.logout')}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
 
      {/* Mobile menu - show when toggled */}
      {isMobileMenuOpen && (
        <>
        {user?.role === 'admin' && (
        <div className="lg:hidden" id="mobile-menu">
          <nav className="px-4 py-3 space-y-1 bg-[#003333]">
            <Link 
              to="/admin/dashboard/nador" 
              className={`block px-3 py-2 rounded-md text-white hover:bg-[#002222] ${!pathname.includes('users') ? 'text-[#ffd699] bg-teal-500 rounded-md' : ''}`}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {t('dashboard.dashboard')}
            </Link>
            <Link 
              to="/admin/dashboard/users" 
              className={`block px-3 py-2 rounded-md text-white hover:bg-[#002222] ${pathname.includes('users') ? 'text-[#ffd699] bg-teal-500 rounded-md' : ''}`}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {t('dashboard.users')}
            </Link>
          </nav>
        </div>
        )}
        </>
      )}

      {/* Language Selection Modal */}
      {showLanguageOptions && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-teal-200 rounded-lg p-4 w-full mx-4 relative 
                        max-h-[90vh] sm:max-h-[80vh] md:max-h-[60vh] overflow-y-auto
                        sm:w-4/5 md:w-3/4 lg:w-1/2 xl:w-2/5">
            {/* Close button */}
            <button
              onClick={closeLanguageOptions}
              className="absolute top-2 right-2 p-1 rounded-full bg-red-500 hover:bg-red-600 text-white"
              aria-label={t('closeLanguageOptions')}
            >
              <X size={20} />
            </button>

            <div className="pt-6 pb-12">
              <h2 className="text-xl font-bold text-center mb-4 text-teal-800">
                {t('language.title')}
              </h2>
              <Language onClose={closeLanguageOptions} />
            </div>
            
            {/* Bottom close button */}
            <div className="text-center mt-4">
              <button
                onClick={closeLanguageOptions}
                className="px-4 py-2 bg-teal-600 text-white rounded-full hover:bg-teal-700 transition-colors"
              >
                {t('common.close')}
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}