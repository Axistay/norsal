"use client"

import { useTranslation } from "react-i18next"
import { useParams } from "react-router-dom"

export function CitySelector({  onCityChange, cities = [] }) {
  const {cityId } = useParams()
  const { t, i18n } = useTranslation()
  const langused = i18n.language

  
  return (
    <div className="bg-white rounded-lg shadow-md border border-[#ffd699] overflow-hidden">
      <div className="p-6">
        <div className="mb-4">
          <h2 className="text-xl font-semibold text-[#004d4d]">{t('dashboard.selectCity')}</h2>
          <p className="text-sm text-[#004d4d]/70">{t('dashboard.chooseCity')}</p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {cities.slice(0, 3).map((city) => (
            <button
              key={city.id}
              className={`h-auto py-3 px-4 rounded-md flex items-center justify-start transition-colors ${
                cityId === city.id
                  ? "bg-[#004d4d] hover:bg-[#003333] text-white"
                  : "border border-[#004d4d] text-[#004d4d] hover:bg-[#ffd699]/20"
              }`}
              onClick={() => onCityChange(city.id)}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4 mr-2"
              >
                <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path>
                <circle cx="12" cy="10" r="3"></circle>
              </svg>
              {city.name[langused] || city.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}