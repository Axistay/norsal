"use client"

import { useState, useEffect } from "react"
import { CategoryForm } from "./category-form"
import { categoryApi } from "../../../lib/api"
import { useNavigate, useParams } from "react-router-dom"
import ImageModal from "./ImageModal"
import { useTranslation } from "react-i18next"

export function CategoryList({ onCategorySelect }) {
  const { t, i18n } = useTranslation()
  const langused = i18n.language

  const [categories, setCategories] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [editingCategory, setEditingCategory] = useState(null)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [showModuleImg, setShowModuleImg] = useState(false)
  const [categoryId, setcategoryId] = useState(null)
  const [categoryToDelete, setCategoryToDelete] = useState(null)
  const { cityId } = useParams()
  const navigate = useNavigate()

  const handleToogle = () => {
    setShowModuleImg(!showModuleImg)
  }

  const openModule = (id, e) => {
    e.stopPropagation()

    setcategoryId(id)
    handleToogle()
  }
  // Load categories 
  const fetchCategories = async () => {
    try {
      const data = await categoryApi.getByCity(cityId || 'nador')
      setCategories(data)
    } catch (error) {
      console.error("Failed to fetch categories:", error)
      setCategories([])
    }
  }

  useEffect(() => {
    fetchCategories()
  }, [])

  const handleEdit = (category, e) => {
    e.stopPropagation()
    setEditingCategory(category)
    setShowForm(true)
  }

  const onSuccess = (data) => {
    if (data) {
      fetchCategories()
    }
  }
  onSuccess()

  const handleAddNew = () => {
    setEditingCategory(null)
    setShowForm(true)
  }

  const handleCloseForm = (refreshData = false) => {
    setShowForm(false)
    setEditingCategory(null)
    if (refreshData) {
      fetchCategories()
    }
  }

  const handleDelete = (category, e) => {
    e.stopPropagation()
    setCategoryToDelete(category)
    setDeleteDialogOpen(true)
  }

  const confirmDelete = async () => {
    try {
      await categoryApi.delete(categoryToDelete?._id)
      fetchCategories()
    } catch (error) {
      console.error("Failed to delete category:", error)
    }
    setDeleteDialogOpen(false)
    setCategoryToDelete(null)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-[#004d4d]">
          {t('categories.categories_title', { count: categories?.length })}
        </h2>
        <button
          onClick={handleAddNew}
          className="bg-[#004d4d] hover:bg-[#003333] text-white px-4 py-2 rounded-md flex items-center"
        >
          {t('categories.add_category')}
        </button>
      </div>

      {showForm && <CategoryForm category={editingCategory} onClose={handleCloseForm} />}
      {showModuleImg && <ImageModal isOpen={showModuleImg} onClose={handleToogle} categoryId={categoryId} onSuccess={onSuccess} type={'categories'} />}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4  gap-6">
        {categories.map((category) => (
          <div
            key={category._id}
            className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer border-8 border-double rounded-lg bg-white" style={{ borderColor: `${category?.color}`}}
            onClick={() => onCategorySelect(category._id)}
          >
            <div className="relative h-40">
              <img
                src={category.image.url || "/placeholder.svg?height=160&width=320"}
                alt={category.name[langused]}
                className="object-cover h-full w-full"
              />
              <div className="absolute inset-0 opacity-20 bg-[#004d4d]"></div>
              <div className="absolute top-2 right-2 flex gap-2">
                <button
                  className="bg-[#ffd699] text-[#004d4d] hover:bg-[#ffd699]/80 px-2 py-1 text-sm rounded"
                  onClick={(e) => openModule(category?._id, e)}
                >
                                    {t('common.img')}

                </button>
                <button
                  className="bg-[#ffd699] text-[#004d4d] hover:bg-[#ffd699]/80 px-2 py-1 text-sm rounded"
                  onClick={(e) => handleEdit(category, e)}
                >
                  {t('common.edit')}

                </button>
                <button
                  className="bg-red-500 hover:bg-red-600 text-white px-2 py-1 text-sm rounded"
                  onClick={(e) => handleDelete(category, e)}
                >
                                    {t('common.delete')}

                </button>
              </div>
            </div>
            <div className="p-4">
              <h3 className="text-lg font-semibold mb-1 text-[#004d4d]">{category.name[langused]}</h3>
              <p className="text-sm text-[#004d4d]/70">{category.description[langused]}</p>
            </div>
          </div>
        ))}
      </div>

      {deleteDialogOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white border border-[#ffd699] rounded-lg p-6 max-w-md w-full">
            <h3 className="text-lg font-semibold text-[#004d4d]">
              {t('categories.confirm_deletion')}
            </h3>
            <p className="text-[#004d4d]/70 my-4">
              {t('categories.delete_confirmation', { categoryName: categoryToDelete?.name[langused] })}
            </p>
            <div className="flex justify-end gap-2">
              <button
                className="border border-[#004d4d] text-[#004d4d] hover:bg-[#ffd699]/20 px-4 py-2 rounded-md"
                onClick={() => setDeleteDialogOpen(false)}
              >
                                  {t('common.cancel')}

              </button>
              <button className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md" onClick={confirmDelete}>
              {t('common.delete')}

              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}