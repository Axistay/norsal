"use client"

import { useState, useEffect } from "react"
import { plateApi } from "../../../lib/api"
import { useParams } from "react-router-dom"
import { useTranslation } from "react-i18next"

export function PlateForm({ plate, onClose }) {
  
  const {cityId} = useParams()
  const {typeId} = useParams()
  const { t } = useTranslation()
  const [formData, setFormData] = useState(
    plate || {
      title: { en: "", fr: "", es: "", ar: "" },
      description: { en: "", fr: "", es: "", ar: "" },
      price: 0,
      image: "",
      typeId,
      nutrition: {
        calories: 0,
        protein: 0,
        fat: 0,
        carbs: 0,
      },
      city : cityId
    }
  )
  const [activeTab, setActiveTab] = useState("en")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!isSubmitting) {
      document.body.classList.add("overflow-hidden");
    } else {
      document.body.classList.remove("overflow-hidden");
    }
    
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, [isSubmitting]);

  const handleChange = (field, value, lang, nutritionField) => {
    if (lang) {
      setFormData({
        ...formData,
        [field]: {
          ...formData[field],
          [lang]: value,
        },
      })
    } else if (nutritionField) {
      setFormData({
        ...formData,
        nutrition: {
          ...formData.nutrition,
          [nutritionField]: value === "" ? 0 : Number(value),
        },
      })
    } else {
      setFormData({
        ...formData,
        [field]: field === "price" ? (value === "" ? 0 : Number(value)) : value,
      })
    }
  }

  const validateForm = () => {
    // Validate required English fields at minimum
    if (!formData.title.en.trim()) {
      setError("English title is required")
      setActiveTab("en")
      return false
    }
    
    if (!formData.description.en.trim()) {
      setError("English description is required")
      setActiveTab("en")
      return false
    }
    
    return true
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError(null)
    
    if (!validateForm()) {
      return
    }
    
    setIsSubmitting(true)
    
    try {
      const dataToSend = { ...formData, city: cityId };

      if (plate) {
        await plateApi.update(dataToSend)
      } else {
        await plateApi.create(dataToSend)
      }
      onClose(true) // true to refresh data
    } catch (err) {
      console.error("Error saving plate:", err)
      setError(err.message || "Failed to save plate. Please try again.")
      setIsSubmitting(false)
    }
  }

  const languages = [
    { code: "en", name: `${t('language.english')}` },
    { code: "fr", name: `${t('language.french')}` },
    { code: "es", name:`${t('language.spanish')}` },
    { code: "ar", name: `${t('language.arabic')}` , dir: "rtl"}
  ] 

  return (
    <div className="fixed inset-0 bg-teal-900 bg-opacity-50 flex items-center justify-center z-50 p-3 md:p-6 overflow-hidden">
      <div className="w-full border border-[#ffd699] rounded-lg bg-white shadow-xl max-w-4xl md:max-w-5xl lg:max-w-7xl h-auto max-h-[95vh] flex flex-col">
        <div className="bg-[#ffd699] px-4 sm:px-6 py-3 sm:py-4 rounded-t-lg sticky top-0 z-10">
          <h3 className="text-base sm:text-lg font-semibold text-[#004d4d]">
            {plate ? t("plates.update_plate") : t("plates.add_plate")}
          </h3>
        </div>
        
        <div className="overflow-y-auto flex-grow">
          {error && (
            <div className="mx-4 sm:mx-6 mt-4 p-2 sm:p-3 bg-red-50 border border-red-300 text-red-700 rounded-md text-sm">
              {error}
            </div>
          )}
          
          <form onSubmit={handleSubmit}>
            <div className="space-y-4 p-4 sm:p-6">
              <div className="mb-4">
                <div className="flex flex-nowrap border-b border-[#ffd699]/30 overflow-x-auto scrollbar-hide">
                  {languages.map(lang => (
                    <button
                      key={lang.code}
                      type="button"
                      className={`px-3 sm:px-4 py-2 text-sm sm:text-base whitespace-nowrap ${
                        activeTab === lang.code ? "bg-[#004d4d] text-white rounded-t-lg" : "text-[#004d4d]"
                      }`}
                      onClick={() => setActiveTab(lang.code)}
                    >
                      {lang.name}
                    </button>
                  ))}
                </div>

                {languages.map(lang => (
                  activeTab === lang.code && (
                    <div key={lang.code} className="space-y-3 sm:space-y-4 mt-3 sm:mt-4">
                      <div className="space-y-1 sm:space-y-2">
                        <label htmlFor={`title-${lang.code}`} className="block text-[#004d4d] text-sm sm:text-base">
                          {t("plates.title")} ({lang.name})
                          {lang.code === "en" && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <input
                          id={`title-${lang.code}`}
                          value={formData.title?.[lang.code] || ""}
                          onChange={(e) => handleChange("title", e.target.value, lang.code)}
                          required
                          dir={lang.dir}
                          className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699] text-sm sm:text-base"
                        />
                      </div>
                      <div className="space-y-1 sm:space-y-2">
                        <label htmlFor={`description-${lang.code}`} className="block text-[#004d4d] text-sm sm:text-base">
                          {t("plates.description")} ({lang.name})
                          {lang.code === "en" && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <textarea
                          id={`description-${lang.code}`}
                          value={formData.description?.[lang.code] || ""}
                          onChange={(e) => handleChange("description", e.target.value, lang.code)}
                          required
                          dir={lang.dir}
                          className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699] text-sm sm:text-base"
                          rows={3}
                        />
                      </div>
                    </div>
                  )
                ))}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                <div className="space-y-1 sm:space-y-2">
                  <label htmlFor="price" className="block text-[#004d4d] text-sm sm:text-base">
                    {t("plates.price")} <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.price || ""}
                    onChange={(e) => handleChange("price", e.target.value)}
                    required
                    className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699] text-sm sm:text-base"
                  />
                </div>
              </div>

              <div>
                <h3 className="text-base sm:text-lg font-medium mb-2 text-[#004d4d]">
                  {t("plates.nutrition_information")}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                  <div className="space-y-1 sm:space-y-2">
                    <label htmlFor="calories" className="block text-[#004d4d] text-sm sm:text-base">
                      {t("plates.calories")} <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="calories"
                      type="number"
                      min="0"
                      value={formData.nutrition?.calories || ""}
                      onChange={(e) => handleChange("nutrition", e.target.value, undefined, "calories")}
                      className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699] text-sm sm:text-base"
                    />
                  </div>
                  <div className="space-y-1 sm:space-y-2">
                    <label htmlFor="protein" className="block text-[#004d4d] text-sm sm:text-base">
                      {t("plates.protein")} <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="protein"
                      type="number"
                      min="0"
                      step="0.1"
                      value={formData.nutrition?.protein || ""}
                      onChange={(e) => handleChange("nutrition", e.target.value, undefined, "protein")}
                      className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699] text-sm sm:text-base"
                    />
                  </div>
                  <div className="space-y-1 sm:space-y-2">
                    <label htmlFor="fat" className="block text-[#004d4d] text-sm sm:text-base">
                      {t("plates.fat")} <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="fat"
                      type="number"
                      min="0"
                      step="0.1"
                      value={formData.nutrition?.fat || ""}
                      onChange={(e) => handleChange("nutrition", e.target.value, undefined, "fat")}
                      className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699] text-sm sm:text-base"
                    />
                  </div>
                  <div className="space-y-1 sm:space-y-2">
                    <label htmlFor="carbs" className="block text-[#004d4d] text-sm sm:text-base">
                      {t("plates.carbs")} <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="carbs"
                      type="number"
                      min="0"
                      step="0.1"
                      value={formData.nutrition?.carbs || ""}
                      onChange={(e) => handleChange("nutrition", e.target.value, undefined, "carbs")}
                      className="w-full border border-[#004d4d] rounded-md p-2 focus:ring-[#ffd699] focus:border-[#ffd699] text-sm sm:text-base"
                    />
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
        
        <div className="flex justify-between p-4 sm:p-6 border-t border-[#ffd699]/30 sticky bottom-0 bg-white z-10">
          <button
            type="button"
            onClick={() => onClose(false)}
            className="border border-[#004d4d] text-[#004d4d] hover:bg-[#ffd699]/20 px-3 sm:px-4 py-1.5 sm:py-2 rounded-md text-sm sm:text-base"
            disabled={isSubmitting}
          >
            {t('common.cancel')}
          </button>
          <button 
           onClick={(e)=> {
            handleSubmit(e)
           }}
            form="plate-form"
            className="bg-[#004d4d] hover:bg-[#003333] text-white px-3 sm:px-4 py-1.5 sm:py-2 rounded-md flex items-center text-sm sm:text-base"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-3 w-3 sm:h-4 sm:w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>{t('common.saving')}</span>
              </>
            ) : (
              plate ? (t('plates.update_plate')) : (t('plates.add_plate'))
            )}
          </button>
        </div>
      </div>
    </div>
  )
}