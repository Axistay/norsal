"use client"

import { useState, useEffect } from "react"
import { useLocation, useNavigate, useParams } from "react-router-dom"
import { ProtectedRoute } from "../protected-route"
import { DashboardHeader } from "./components/header"
import { CitySelector } from "./components/city-selector"
import { CategoryList } from "./components/category-list"
import { TypeList } from "./components/type-list"
import { PlateList } from "./components/plate-list"
import { initializeData } from "../lib/data-utils"
import { useTranslation } from "react-i18next"
import DashboardUsers from "./users/page"
import { useAuth } from "../../context/AuthContext"
export default function DashboardPage({ cities = [], type }) {
  const {user} = useAuth()
  const location = useLocation()
  const path = location.pathname
  const navigate = useNavigate()
  const params = useParams()
  const { t, i18n } = useTranslation()
  const langused = i18n.language

  const [selectedCity, setSelectedCity] = useState(null)
  const [selectedCategory, setSelectedCategory] = useState(0)
  const [selectedType, setSelectedType] = useState(null)
  const [isDataInitialized, setIsDataInitialized] = useState(false)
  const [filteredCities, setFilteredCities] = useState(cities);

  // Initialize data and sync with URL params
  useEffect(() => {
    if (!isDataInitialized && typeof window !== "undefined") {
      initializeData();
      setIsDataInitialized(true);

      // Get city from URL params or default to user's role city
      let cityId = user?.role === 'admin' ? 'nador' : user?.role;

      setSelectedCity(cityId);

      if (!params.cityId && type !== 'users') {
        navigate(`/admin/dashboard/${cityId}`);
      } else if (user?.role !== 'admin' && params.cityId !== user?.role) {
        // Redirect non-admin users to their specific city route
        navigate(`/admin/dashboard/${user?.role}`);
      }
    }
  }, [isDataInitialized, user, params, type, navigate]);

  // Filter cities based on user role
  useEffect(() => {
    if (user?.role !== 'admin') {
      setFilteredCities(cities.filter(city => city === user?.role));
    } else {
      setFilteredCities(cities);
    }
  }, [user, cities]);

  // Reset selections when changing higher level
  const handleCityChange = (cityId) => {
    setSelectedCity(cityId)
    setSelectedCategory(null)
    setSelectedType(null)
    navigate(`/admin/dashboard/${cityId}`)
  }

  const handleCategorySelect = (categoryId) => {
    setSelectedType(null)
    navigate(`/admin/dashboard/${selectedCity}/category/${categoryId}`)
  }


  const handleTypeSelect = (typeId, categoryId) => {
    setSelectedType(typeId)
    navigate(`/admin/dashboard/${selectedCity}/category/${categoryId}/type/${typeId}`)
  }

  const handleBack = () => {

    navigate(-1)

  }

  // Show loading state when data is not initialized yet
  if (!isDataInitialized) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p>{t('dashboard.loading')}</p>
      </div>
    )
  }

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gray-50">
        <DashboardHeader />
        <main className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-[#004d4d]">{t('dashboard.menuTitle')}</h1>
            <p className="text-[#004d4d]/70">{t('dashboard.manageMenu')}</p>
          </div>
       
         
          {
            (type === 'users' && user?.role === 'admin') ? <DashboardUsers /> : (
            <div className="grid gap-6">
              {user?.role === 'admin' && (
              <CitySelector
                selectedCity={selectedCity}
                onCityChange={handleCityChange}
                cities={filteredCities}
              />
              )}


              {selectedCity && (
                <div className="space-y-6">
                  {!selectedCategory && type === 'categories' ? (
                    <CategoryList
                      cityId={selectedCity}
                      onCategorySelect={handleCategorySelect}
                    />
                  ) : !selectedType && type === 'types' ? (
                    <TypeList
                      cityId={selectedCity}
                      onTypeSelect={handleTypeSelect}
                      onBack={handleBack}
                    />
                  ) : (
                    <PlateList
                      cityId={selectedCity}
                      categoryId={selectedCategory}
                      typeId={selectedType}
                      onBack={handleBack}
                    />
                  )}
                </div>
              )}
            </div>)
          }



        </main>
      </div>
    </ProtectedRoute>
  )
}