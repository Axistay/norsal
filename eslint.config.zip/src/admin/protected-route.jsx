"use client"

import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { useAuth } from "../context/AuthContext"
export function ProtectedRoute({ children }) {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const { isAuthenticated } = useAuth()
  useEffect(() => {
    // Check if user is authenticated
    if (!isAuthenticated()) {
      navigate("/admin/login")
    } else {
      setLoading(false)
    }
  }, [navigate])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#004d4d]">
        <div className="text-white text-xl">Loading...</div>
      </div>
    )
  }

  return children
}
