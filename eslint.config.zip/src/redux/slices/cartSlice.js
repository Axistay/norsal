import { createSlice } from "@reduxjs/toolkit";

// Helper to load cart from localStorage
const loadCart = () => {
  try {
    const stored = localStorage.getItem("cart");
    if (!stored) return { items: [], total: 0 };
    
    const parsedCart = JSON.parse(stored);
    
    // Validate the structure to ensure we have valid data
    if (!Array.isArray(parsedCart.items)) {
      return { items: [], total: 0 };
    }
    
    // Recalculate total to ensure consistency
    const validatedCart = {
      items: parsedCart.items.filter(item => 
        item && typeof item === 'object' && 
        item._id && 
        typeof item.price === 'number' &&
        typeof item.quantity === 'number'
      ),
      total: 0
    };
    
    validatedCart.total = validatedCart.items.reduce(
      (total, item) => total + (item.price * item.quantity), 
      0
    );
    
    return validatedCart;
  } catch (error) {
    console.error("Failed to load cart from localStorage:", error);
    return { items: [], total: 0 };
  }
};

// Helper to save cart to localStorage
const saveCart = (state) => {
  try {
    localStorage.setItem("cart", JSON.stringify({
      items: state.items,
      total: state.total
    }));
  } catch (error) {
    console.error("Failed to save cart to localStorage:", error);
  }
};

const initialState = loadCart();

export const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    addToCart: (state, action) => {
      const { _id, price, name, image } = action.payload;
      
      // Ensure we have valid data
      if (!_id || typeof price !== 'number') {
        return state;
      }
      
      const existingItem = state.items.find(item => item._id === _id);
      
      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        state.items.push({ 
          _id, 
          price, 
          name: name || 'Unknown Item',
          image, 
          quantity: 1 
        });
      }
      
      // Recalculate total
      state.total = state.items.reduce(
        (total, item) => total + item.price * item.quantity, 
        0
      );
      
      saveCart(state);
    },
    
    removeFromCart: (state, action) => {
      const idToRemove = action.payload;
      
      state.items = state.items.filter(item => item._id !== idToRemove);
      
      // Recalculate total
      state.total = state.items.reduce(
        (total, item) => total + item.price * item.quantity, 
        0
      );
      
      saveCart(state);
    },
    
    updateQuantity: (state, action) => {
      const { _id, quantity } = action.payload;
      
      if (!_id || typeof quantity !== 'number') {
        return state;
      }
      
      if (quantity <= 0) {
        // Remove item if quantity is zero or less
        state.items = state.items.filter(item => item._id !== _id);
      } else {
        const item = state.items.find(item => item._id === _id);
        if (item) {
          item.quantity = quantity;
        }
      }
      
      // Recalculate total
      state.total = state.items.reduce(
        (total, item) => total + item.price * item.quantity, 
        0
      );
      
      saveCart(state);
    },
    
    clearCart: (state) => {
      state.items = [];
      state.total = 0;
      saveCart(state);
    },
  },
});

export const { addToCart, removeFromCart, updateQuantity, clearCart } = cartSlice.actions;

export default cartSlice.reducer;