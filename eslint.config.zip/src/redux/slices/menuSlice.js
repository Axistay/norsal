import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  categories: [],
  plates: [],
  types: [],
  filteredPlates: [],
  searchTerm: "",
  currentCategory: null,
};

export const menuSlice = createSlice({
  name: "menu",
  initialState,
  reducers: {
    setInitialMenuData: (state, action) => {
      state.categories = action.payload?.categories || [];
      state.plates = action.payload?.plates || [];
      state.types = action.payload?.types || [];
    },
    setCurrentCategory: (state, action) => {
      state.currentCategory = action.payload;
      
      // Filter plates based on their typeId that belongs to the current category
      if (action.payload) {
        state.filteredPlates = state.plates.filter((plate) => {
          // Get the plate's typeId (handle both string and object cases)
          const plateTypeId = typeof plate.typeId === 'object' 
            ? plate.typeId?._id?.toString() 
            : plate.typeId?.toString();
          
          if (!plateTypeId) return false;
          
          // Find the type that matches this typeId
          const matchingType = state.types.find(type => {
            const typeId = typeof type._id === 'object'
              ? type._id?.toString()
              : type._id?.toString();
            return typeId === plateTypeId;
          });
          
          if (!matchingType) return false;
          
          // Check if the type's categoryId matches the current category
          const typeCategoryId = typeof matchingType.categoryId === 'object'
            ? matchingType.categoryId?._id?.toString()
            : matchingType.categoryId?.toString();
            
          return typeCategoryId === action.payload;
        });
      } else {
        state.filteredPlates = [];
      }
    },
    setSearchTerm: (state, action) => {
      const term = action.payload.toLowerCase();
      state.searchTerm = term;
      
      // Helper function to check if a plate matches the search term in any language
      const matchesSearchTerm = (plate) => {
        if (!plate) return false;
        
        // Check title in all languages (en, fr, es, ar)
        const titleMatch = Object.entries(plate.title || {}).some(([lang, value]) => {
          return value && typeof value === 'string' && value.toLowerCase().includes(term);
        });
        
        // Check description in all languages (en, fr, es, ar)
        const descriptionMatch = Object.entries(plate.description || {}).some(([lang, value]) => {
          return value && typeof value === 'string' && value.toLowerCase().includes(term);
        });
        
        return titleMatch || descriptionMatch;
      };
      
      // Filter plates based on search term and current category (if set)
      if (state.currentCategory) {
        // First filter by category, then by search term
        state.filteredPlates = state.plates.filter((plate) => {
          // Get the plate's typeId (handle both string and object cases)
          const plateTypeId = typeof plate.typeId === 'object' 
            ? plate.typeId?._id?.toString() 
            : plate.typeId?.toString();
          
          if (!plateTypeId) return false;
          
          // Find the type that matches this typeId
          const matchingType = state.types.find(type => {
            const typeId = typeof type._id === 'object'
              ? type._id?.toString()
              : type._id?.toString();
            return typeId === plateTypeId;
          });
          
          if (!matchingType) return false;
          
          // Check if the type's categoryId matches the current category
          const typeCategoryId = typeof matchingType.categoryId === 'object'
            ? matchingType.categoryId?._id?.toString()
            : matchingType.categoryId?.toString();
            
          return typeCategoryId === state.currentCategory && matchesSearchTerm(plate);
        });
      } else {
        // Just filter by search term
        state.filteredPlates = state.plates.filter(matchesSearchTerm);
      }
    },
    clearSearch: (state) => {
      state.searchTerm = "";
      
      // If there's a current category, filter by that only
      if (state.currentCategory) {
        state.filteredPlates = state.plates.filter((plate) => {
          // Get the plate's typeId (handle both string and object cases)
          const plateTypeId = typeof plate.typeId === 'object' 
            ? plate.typeId?._id?.toString() 
            : plate.typeId?.toString();
          
          if (!plateTypeId) return false;
          
          // Find the type that matches this typeId
          const matchingType = state.types.find(type => {
            const typeId = typeof type._id === 'object'
              ? type._id?.toString()
              : type._id?.toString();
            return typeId === plateTypeId;
          });
          
          if (!matchingType) return false;
          
          // Check if the type's categoryId matches the current category
          const typeCategoryId = typeof matchingType.categoryId === 'object'
            ? matchingType.categoryId?._id?.toString()
            : matchingType.categoryId?.toString();
            
          return typeCategoryId === state.currentCategory;
        });
      } else {
        state.filteredPlates = [];
      }
    },
  },
});

export const {
  setInitialMenuData,
  setCurrentCategory,
  setSearchTerm,
  clearSearch,
} = menuSlice.actions;

export default menuSlice.reducer;